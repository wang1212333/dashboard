#!/usr/bin/env python3
"""Call a configured data-mcp server through MCP Streamable HTTP."""

from __future__ import annotations

import json
import os
import sys
import tomllib
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any


PROTOCOL_VERSION = "2025-06-18"
CLIENT_INFO = {"name": "t-agent-skill", "version": "1.0"}


class ClientFailure(Exception):
    def __init__(self, category: str) -> None:
        super().__init__(category)
        self.category = category


def config_path() -> Path:
    codex_home = os.environ.get("CODEX_HOME")
    return Path(codex_home) / "config.toml" if codex_home else Path.home() / ".codex" / "config.toml"


def read_server_config() -> tuple[str, dict[str, str]]:
    try:
        config = tomllib.loads(config_path().read_text(encoding="utf-8"))
        server = config["mcp_servers"]["data-mcp"]
        url = server["url"]
        headers = dict(server.get("http_headers", {}))
    except (OSError, KeyError, TypeError, tomllib.TOMLDecodeError) as exc:
        raise ClientFailure("configuration failed") from exc
    if not isinstance(url, str) or not url.strip():
        raise ClientFailure("configuration failed")
    return url, {str(key): str(value) for key, value in headers.items()}


def read_input() -> dict[str, Any]:
    if len(sys.argv) != 1:
        raise ClientFailure("input validation failed")
    try:
        value = json.load(sys.stdin)
    except (json.JSONDecodeError, UnicodeError) as exc:
        raise ClientFailure("input validation failed") from exc
    if not isinstance(value, dict):
        raise ClientFailure("input validation failed")
    operation = value.get("operation")
    token = value.get("token")
    if operation not in {"list_tools", "call_tool"} or not isinstance(token, str) or not token.strip():
        raise ClientFailure("input validation failed")
    if operation == "call_tool":
        if not isinstance(value.get("tool"), str) or not isinstance(value.get("arguments"), dict):
            raise ClientFailure("input validation failed")
    return value


def authorization_value(token: str) -> str:
    token = token.strip()
    if token.lower().startswith("bearer "):
        token = token[7:].strip()
    if not token:
        raise ClientFailure("input validation failed")
    return f"Bearer {token}"


def parse_message(body: bytes, content_type: str, request_id: int) -> dict[str, Any]:
    try:
        text = body.decode("utf-8")
        if "text/event-stream" not in content_type.lower():
            message = json.loads(text)
            if not isinstance(message, dict):
                raise ValueError
            return message

        matching: dict[str, Any] | None = None
        data_lines: list[str] = []
        for line in text.splitlines() + [""]:
            if line.startswith("data:"):
                data_lines.append(line[5:].lstrip())
            elif not line and data_lines:
                event = json.loads("\n".join(data_lines))
                data_lines.clear()
                if isinstance(event, dict) and event.get("id") == request_id:
                    matching = event
        if matching is None:
            raise ValueError
        return matching
    except (UnicodeError, json.JSONDecodeError, ValueError) as exc:
        raise ClientFailure("protocol failed") from exc


class StreamableHTTPClient:
    def __init__(self, url: str, headers: dict[str, str]) -> None:
        self.url = url
        self.headers = headers
        self.session_id: str | None = None
        self.protocol_version = PROTOCOL_VERSION
        self.request_id = 0
        self.opener = urllib.request.build_opener()

    def next_id(self) -> int:
        self.request_id += 1
        return self.request_id

    def request_headers(self, initialized: bool) -> dict[str, str]:
        headers = dict(self.headers)
        headers["Accept"] = "application/json, text/event-stream"
        headers["Content-Type"] = "application/json"
        if initialized:
            headers["MCP-Protocol-Version"] = self.protocol_version
            if self.session_id:
                headers["Mcp-Session-Id"] = self.session_id
        return headers

    def post(self, message: dict[str, Any], initialized: bool, expect_response: bool) -> dict[str, Any] | None:
        request_id = message.get("id")
        request = urllib.request.Request(
            self.url,
            data=json.dumps(message, separators=(",", ":")).encode("utf-8"),
            headers=self.request_headers(initialized),
            method="POST",
        )
        try:
            with self.opener.open(request, timeout=120) as response:
                status = response.status
                body = response.read()
                content_type = response.headers.get("Content-Type", "")
                if not initialized:
                    self.session_id = response.headers.get("Mcp-Session-Id")
        except urllib.error.HTTPError as exc:
            if exc.code in {401, 403}:
                raise ClientFailure("authorization failed") from exc
            raise ClientFailure("connection failed") from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise ClientFailure("connection failed") from exc

        if not expect_response:
            if status not in {200, 202, 204}:
                raise ClientFailure("protocol failed")
            return None
        if not body or not isinstance(request_id, int):
            raise ClientFailure("protocol failed")
        parsed = parse_message(body, content_type, request_id)
        if parsed.get("id") != request_id or "error" in parsed:
            raise ClientFailure("protocol failed")
        return parsed

    def initialize(self) -> None:
        request_id = self.next_id()
        response = self.post(
            {
                "jsonrpc": "2.0",
                "id": request_id,
                "method": "initialize",
                "params": {
                    "protocolVersion": PROTOCOL_VERSION,
                    "capabilities": {},
                    "clientInfo": CLIENT_INFO,
                },
            },
            initialized=False,
            expect_response=True,
        )
        result = response.get("result") if response else None
        if not isinstance(result, dict) or not isinstance(result.get("protocolVersion"), str):
            raise ClientFailure("protocol failed")
        self.protocol_version = result["protocolVersion"]
        self.post(
            {"jsonrpc": "2.0", "method": "notifications/initialized"},
            initialized=True,
            expect_response=False,
        )

    def list_tools(self) -> list[dict[str, Any]]:
        tools: list[dict[str, Any]] = []
        cursor: str | None = None
        while True:
            request_id = self.next_id()
            params = {"cursor": cursor} if cursor else {}
            response = self.post(
                {"jsonrpc": "2.0", "id": request_id, "method": "tools/list", "params": params},
                initialized=True,
                expect_response=True,
            )
            result = response.get("result") if response else None
            page = result.get("tools") if isinstance(result, dict) else None
            if not isinstance(page, list) or not all(isinstance(item, dict) for item in page):
                raise ClientFailure("tool discovery failed")
            tools.extend(page)
            cursor = result.get("nextCursor")
            if not cursor:
                return tools
            if not isinstance(cursor, str):
                raise ClientFailure("tool discovery failed")

    def call_tool(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        request_id = self.next_id()
        response = self.post(
            {
                "jsonrpc": "2.0",
                "id": request_id,
                "method": "tools/call",
                "params": {"name": name, "arguments": arguments},
            },
            initialized=True,
            expect_response=True,
        )
        result = response.get("result") if response else None
        if not isinstance(result, dict) or result.get("isError") is True:
            raise ClientFailure("tool call failed")
        return result

    def close(self) -> None:
        if not self.session_id:
            return
        request = urllib.request.Request(
            self.url,
            headers=self.request_headers(initialized=True),
            method="DELETE",
        )
        try:
            self.opener.open(request, timeout=5).close()
        except Exception:
            pass


def select_tool(tools: list[dict[str, Any]], requested: str, arguments: dict[str, Any]) -> str:
    exact = [tool for tool in tools if tool.get("name") == requested]
    if len(exact) == 1:
        return requested
    if "sql" not in arguments:
        raise ClientFailure("tool discovery failed")

    candidates: list[str] = []
    for tool in tools:
        schema = tool.get("inputSchema")
        properties = schema.get("properties") if isinstance(schema, dict) else None
        description = str(tool.get("description", "")).lower()
        name = tool.get("name")
        read_only = "read-only" in description or "readonly" in description or "只读" in description
        if isinstance(name, str) and isinstance(properties, dict) and "sql" in properties and read_only:
            candidates.append(name)
    if len(candidates) != 1:
        raise ClientFailure("tool discovery failed")
    return candidates[0]


def redact(value: Any, secrets: list[str]) -> Any:
    if isinstance(value, str):
        for secret in secrets:
            if secret:
                value = value.replace(secret, "[redacted]")
        return value
    if isinstance(value, list):
        return [redact(item, secrets) for item in value]
    if isinstance(value, dict):
        return {key: redact(item, secrets) for key, item in value.items()}
    return value


def run() -> dict[str, Any]:
    request = read_input()
    url, configured_headers = read_server_config()
    headers = {key: value for key, value in configured_headers.items() if key.lower() != "authorization"}
    auth = authorization_value(request["token"])
    headers["Authorization"] = auth
    client = StreamableHTTPClient(url, headers)
    try:
        client.initialize()
        tools = client.list_tools()
        if not tools:
            raise ClientFailure("tool discovery failed")
        if request["operation"] == "list_tools":
            result: dict[str, Any] = {"tools": tools}
        else:
            arguments = request["arguments"]
            selected = select_tool(tools, request["tool"], arguments)
            result = client.call_tool(selected, arguments)
    finally:
        client.close()

    secrets = [request["token"], auth, url]
    sql = request.get("arguments", {}).get("sql")
    if isinstance(sql, str):
        secrets.append(sql)
    return redact(result, secrets)


def main() -> int:
    try:
        result = run()
    except ClientFailure as exc:
        print(f"data-mcp client error: {exc.category}", file=sys.stderr)
        return 1
    except Exception:
        print("data-mcp client error: protocol failed", file=sys.stderr)
        return 1
    payload = json.dumps(result, ensure_ascii=False, separators=(",", ":")) + "\n"
    sys.stdout.buffer.write(payload.encode("utf-8"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
