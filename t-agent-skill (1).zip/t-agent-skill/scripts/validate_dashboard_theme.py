#!/usr/bin/env python3
"""Validate a single-file offline operations dashboard."""

from __future__ import annotations

import argparse
import html
import re
import sys
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path


REQUIRED_TOKENS = (
    "--primary",
    "--secondary",
    "--info",
    "--success",
    "--warning",
    "--destructive",
    "--background",
    "--foreground",
    "--muted",
    "--border",
    "--glass-card",
    "--glass-border",
    "--hero-from",
    "--hero-via",
    "--hero-to",
)

REQUIRED_COLORS = {
    "page background": ("#f5f7fb",),
    "primary indigo": ("#4f46e5", "243 75% 59%"),
    "secondary violet": ("#7c3aed", "258 90% 66%"),
    "information sky": ("#0ea5e9", "199 89% 48%"),
    "success emerald": ("#10b981", "160 84% 39%"),
    "foreground slate": ("#0f172a", "222 47% 11%"),
}

REQUIRED_FONTS = ("inter", "noto sans sc")
SUPERSEDED_IDENTITY_COLORS = ("#0080ff", "#8b00ff", "#22c55e")

RUNTIME_CONNECTION_PATTERNS = {
    "CSS import": r"@import\b",
    "runtime fetch": r"\bfetch\s*\(",
    "XMLHttpRequest": r"\bxmlhttprequest\b",
    "WebSocket": r"\bwebsocket\s*\(",
    "EventSource": r"\beventsource\s*\(",
    "sendBeacon": r"\bsendbeacon\s*\(",
    "importScripts": r"\bimportscripts\s*\(",
    "dynamic import": r"\bimport\s*\(",
    "dynamic resource object": r"\bnew\s+(?:image|audio)\s*\(",
    "dynamic resource element": (
        r"\bcreateelement\s*\(\s*[\"'](?:script|link|img|iframe|object|embed)[\"']"
    ),
    "dynamic resource assignment": (
        r"(?:\.\s*(?:src|srcset|href|poster)|"
        r"\[\s*[\"'](?:src|srcset|href|poster)[\"']\s*\])\s*="
    ),
    "navigation request": (
        r"\b(?:window\s*\.\s*open|location\s*\.\s*(?:assign|replace))\s*\("
    ),
}

TECHNICAL_PATTERNS = {
    "OpenMetadata": r"\bopenmetadata\b|开放元数据",
    "omd-mcp": r"\bomd[-_]mcp\b",
    "data-mcp": r"\bdata[-_]mcp\b",
    "MCP": r"\bmcp\b",
    "SQL": r"\bsql\b",
    "authorization": r"\bauthorization\b|授权头",
    "token": r"\btoken\b|令牌",
    "demo or sample data": r"\bdemo\s+data\b|\bsample\s+data\b|演示数据|示例数据",
    "pending integration": r"\bpending\s+integration\b|待接入",
    "query template": r"\bquery\s+template\b|查询模板",
    "database disclosure": r"数据库名称|数据库名",
    "table disclosure": r"数据表名称|数据表名|表名",
}

SECRET_PATTERNS = {
    "authorization header value": r"\bauthorization\s*[:=]",
    "bearer credential": r"\bbearer\s+[a-z0-9._~+/=-]{8,}",
    "JWT-like credential": r"\beyj[a-z0-9_-]{8,}\.[a-z0-9_-]{8,}\.[a-z0-9_-]{8,}\b",
    "assigned token value": r"\btoken\s*[:=]\s*[\"'][^\"']+[\"']",
}

QUERY_PATTERNS = {
    "CTE statement": r"\bwith\s+[a-z_][\w$]*\s+as\s*\(\s*select\b",
    "INSERT statement": r"\binsert\s+into\b",
    "UPDATE statement": r"\bupdate\s+[a-z_][\w$.\"']*\s+set\b",
    "DELETE statement": r"\bdelete\s+from\b",
    "MERGE statement": r"\bmerge\s+into\b",
    "DDL statement": r"\b(?:create|alter|drop|truncate)\s+(?:table|view|schema|database|index)\b",
    "privilege statement": r"\b(?:grant|revoke)\b.{0,300}?\bon\b",
    "procedure statement": r"\b(?:call|exec|execute)\s+[a-z_][\w$.\"']*\s*\(",
    "transfer statement": r"\b(?:copy|load|unload)\b.{0,300}?\b(?:from|into)\b",
}

ROLE_TAGS = {
    "summary": {"header"},
    "filters": {"section", "form"},
    "kpi": {"article", "section"},
    "trend": {"section", "article"},
    "comparison": {"section", "article"},
    "diagnostic": {"section", "article"},
    "detail": {"section", "article"},
    "actions": {"section", "article"},
}

RESOURCE_TAGS = {"iframe", "object", "embed", "base"}
RESOURCE_ATTRIBUTES = {"src", "srcset", "poster", "action", "formaction", "data"}


@dataclass
class RoleRegion:
    role: str
    tag: str
    hidden: bool
    freshness: str
    css_tokens: set[str]
    text: list[str] = field(default_factory=list)

    @property
    def has_content(self) -> bool:
        return bool("".join(self.text).strip())


class DashboardHTMLInspector(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.attribute_values: list[str] = []
        self.comments: list[str] = []
        self.rendered_parts: list[str] = []
        self.visible_parts: list[str] = []
        self.style_parts: list[str] = []
        self.script_parts: list[str] = []
        self.roles: list[RoleRegion] = []
        self.stack: list[tuple[str, list[int], bool, set[str]]] = []
        self.errors: list[str] = []
        self.has_html_lang = False
        self.has_viewport = False
        self.inline_style_count = 0
        self.inline_script_count = 0

    @staticmethod
    def _is_embedded_target(value: str) -> bool:
        target = value.strip().lower()
        return not target or target.startswith(("#", "data:"))

    def _inspect_css_urls(self, css: str) -> None:
        for match in re.finditer(
            r"url\(\s*([\"']?)(.*?)\1\s*\)", css, flags=re.IGNORECASE | re.DOTALL
        ):
            target = match.group(2).strip()
            if not self._is_embedded_target(target):
                self.errors.append(
                    f"external dependency or connection present: CSS url({target})"
                )

    def handle_starttag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        tag = tag.lower()
        attr_map = {name.lower(): value or "" for name, value in attrs}
        self.attribute_values.extend(attr_map.values())

        parent_active = self.stack[-1][1] if self.stack else []
        parent_hidden = self.stack[-1][2] if self.stack else False
        parent_css_tokens = self.stack[-1][3] if self.stack else set()
        own_style = attr_map.get("style", "")
        hidden = (
            parent_hidden
            or "hidden" in attr_map
            or attr_map.get("aria-hidden", "").lower() == "true"
            or re.search(r"(?:display\s*:\s*none|visibility\s*:\s*hidden)", own_style)
            is not None
        )

        if tag == "html" and attr_map.get("lang", "").strip():
            self.has_html_lang = True
        if (
            tag == "meta"
            and attr_map.get("name", "").lower() == "viewport"
            and attr_map.get("content", "").strip()
        ):
            self.has_viewport = True
        if tag == "style":
            self.inline_style_count += 1
        if tag == "script" and not attr_map.get("src", "").strip():
            self.inline_script_count += 1

        if tag == "script" and attr_map.get("src", "").strip():
            self.errors.append(
                "external dependency or connection present: script[src]"
            )
        if tag in RESOURCE_TAGS:
            self.errors.append(
                f"external dependency or connection present: <{tag}> element"
            )
        if tag == "link" and attr_map.get("href", "").strip():
            self.errors.append(
                "external dependency or connection present: <link href>"
            )
        for name in RESOURCE_ATTRIBUTES:
            value = attr_map.get(name, "")
            if name == "srcset" and value:
                self.errors.append(
                    f"external dependency or connection present: {tag}[srcset]"
                )
                continue
            if value and not self._is_embedded_target(value):
                self.errors.append(
                    f"external dependency or connection present: {tag}[{name}]"
                )
        href = attr_map.get("href", "")
        if href and not self._is_embedded_target(href):
            self.errors.append(
                f"external dependency or connection present: {tag}[href]"
            )
        if own_style:
            self._inspect_css_urls(own_style)

        own_css_tokens = {tag}
        own_css_tokens.update(
            f".{name}" for name in attr_map.get("class", "").split() if name
        )
        if attr_map.get("id", "").strip():
            own_css_tokens.add(f"#{attr_map['id'].strip()}")

        active = list(parent_active)
        role = attr_map.get("data-dashboard-role", "").lower().strip()
        if role:
            own_css_tokens.add(f'[data-dashboard-role="{role}"]')
            index = len(self.roles)
            self.roles.append(
                RoleRegion(
                    role=role,
                    tag=tag,
                    hidden=hidden,
                    freshness=attr_map.get("data-freshness", "").strip(),
                    css_tokens=set(parent_css_tokens) | own_css_tokens,
                )
            )
            active.append(index)

        if tag in {
            "address",
            "article",
            "aside",
            "div",
            "footer",
            "form",
            "header",
            "main",
            "nav",
            "p",
            "pre",
            "section",
            "table",
            "title",
        }:
            self.visible_parts.append("\n\n")

        self.stack.append(
            (tag, active, hidden, set(parent_css_tokens) | own_css_tokens)
        )

    def handle_startendtag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {
            "address",
            "article",
            "aside",
            "div",
            "footer",
            "form",
            "header",
            "main",
            "nav",
            "p",
            "pre",
            "section",
            "table",
            "title",
        }:
            self.visible_parts.append("\n\n")
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                del self.stack[index:]
                return

    def handle_data(self, data: str) -> None:
        self.rendered_parts.append(data)
        if self.stack:
            tag, active, hidden, _ = self.stack[-1]
            if tag == "style":
                self.style_parts.append(data)
            elif tag == "script":
                self.script_parts.append(data)
            else:
                self.visible_parts.append(data)
            if not hidden:
                for index in active:
                    self.roles[index].text.append(data)

    def handle_comment(self, data: str) -> None:
        self.comments.append(html.unescape(data))

    @property
    def rendered_text(self) -> str:
        return "".join(self.rendered_parts)

    @property
    def visible_text(self) -> str:
        return "".join(self.visible_parts)


def normalized_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower())


def contains_dynamic_term(text: str, term: str) -> bool:
    escaped = re.escape(term.strip().lower())
    if not escaped:
        return False
    prefix = r"(?<![\w])" if term[0].isalnum() or term[0] == "_" else ""
    suffix = r"(?![\w])" if term[-1].isalnum() or term[-1] == "_" else ""
    return re.search(prefix + escaped + suffix, text, flags=re.IGNORECASE) is not None


def hidden_css_requirements(css: str) -> list[set[str]]:
    css = re.sub(r"/\*.*?\*/", "", css, flags=re.DOTALL)
    requirements: list[set[str]] = []
    for match in re.finditer(r"([^{}]+)\{([^{}]*)\}", css, flags=re.DOTALL):
        selectors, declarations = match.groups()
        if not re.search(
            r"(?:display\s*:\s*none|visibility\s*:\s*hidden)", declarations
        ):
            continue
        for selector in selectors.split(","):
            tokens = set(re.findall(r"[.#][a-z_][\w-]*", selector, re.IGNORECASE))
            tokens.update(
                f'[data-dashboard-role="{role.lower()}"]'
                for role in re.findall(
                    r"\[data-dashboard-role\s*=\s*[\"']?([\w-]+)",
                    selector,
                    re.IGNORECASE,
                )
            )
            stripped = selector.strip().lower()
            if stripped in ROLE_TAGS:
                tokens.add(stripped)
            if tokens:
                requirements.append(tokens)
    return requirements


def contains_query_text(segment: str) -> str | None:
    decoded = html.unescape(segment)
    decoded = re.sub(r"/\*.*?\*/", " ", decoded, flags=re.DOTALL)
    decoded = re.sub(r"--[^\n\r]*", " ", decoded)
    normalized = normalized_text(decoded)
    if not normalized:
        return None
    for label, pattern in QUERY_PATTERNS.items():
        if re.search(pattern, normalized, flags=re.IGNORECASE):
            return label

    match = re.search(r"\bselect\b\s+(.+)", normalized, flags=re.IGNORECASE)
    if not match:
        return None
    body = match.group(1).strip()
    sql_shape = (
        r"^(?:distinct\s+)?(?:"
        r"\*|\d|[\"']|null\b|true\b|false\b|case\b|"
        r"[a-z_][\w$]*\s*\(|[a-z_][\w$]*[_.$][\w$]*|"
        r"[a-z_][\w$]*\s*,|[a-z_][\w$]*\s+from\b)"
    )
    if re.search(sql_shape, body, flags=re.IGNORECASE):
        return "SELECT statement"
    return None


def validate_dashboard(
    text: str, forbidden_terms: list[str], custom_theme: bool = False
) -> list[str]:
    lower = text.lower()
    normalized = normalized_text(text)
    errors: list[str] = []

    inspector = DashboardHTMLInspector()
    inspector.feed(text)
    inspector.close()
    errors.extend(inspector.errors)

    decoded_corpus = "\n".join(
        (
            text,
            html.unescape(text),
            inspector.rendered_text,
            "\n".join(inspector.attribute_values),
            "\n".join(inspector.comments),
        )
    )
    if not re.search(r"<!doctype\s+html", lower):
        errors.append("missing HTML doctype")
    if not inspector.has_html_lang:
        errors.append("missing document language")
    if not inspector.has_viewport:
        errors.append("missing responsive viewport metadata")
    if inspector.inline_style_count < 1:
        errors.append("missing inline style")
    if inspector.inline_script_count < 1:
        errors.append("missing inline script")

    for label, pattern in RUNTIME_CONNECTION_PATTERNS.items():
        if re.search(pattern, lower, flags=re.IGNORECASE):
            errors.append(f"external dependency or connection present: {label}")
    script_corpus = html.unescape("\n".join(inspector.script_parts))
    if re.search(
        r"https?://|(?<!:)//[a-z0-9][a-z0-9.-]+\.[a-z]{2,}",
        script_corpus,
        flags=re.IGNORECASE,
    ):
        errors.append(
            "external dependency or connection present: remote URL in script"
        )
    inspector._inspect_css_urls("\n".join(inspector.style_parts))
    inspector._inspect_css_urls(script_corpus)
    errors.extend(error for error in inspector.errors if error not in errors)

    for token in REQUIRED_TOKENS:
        if not re.search(rf"{re.escape(token)}\s*:", normalized):
            errors.append(f"missing semantic/default token {token}")

    if not custom_theme:
        for label, alternatives in REQUIRED_COLORS.items():
            if not any(value in normalized for value in alternatives):
                errors.append(f"missing default {label}: {alternatives[0]}")
        for font in REQUIRED_FONTS:
            if font not in normalized:
                errors.append(f"missing default font: {font.title()}")
        for color in SUPERSEDED_IDENTITY_COLORS:
            if color in normalized:
                errors.append(f"superseded identity color present: {color.upper()}")
        if "blur(14px)" not in normalized:
            errors.append("missing required 14px glass blur")
        if "linear-gradient(135deg" not in normalized:
            errors.append("missing required hero gradient")

    if not re.search(r"@media\s*\([^)]*max-width", lower):
        errors.append("missing responsive max-width media rule")
    if "prefers-color-scheme" not in lower and not re.search(
        r"data-theme[^\n>]{0,80}dark", lower
    ):
        errors.append("missing intentional dark theme")
    if "prefers-reduced-motion" not in lower:
        errors.append("missing reduced-motion support")

    css_hidden = hidden_css_requirements("\n".join(inspector.style_parts))
    visible_roles: dict[str, list[RoleRegion]] = {name: [] for name in ROLE_TAGS}
    for region in inspector.roles:
        hidden_by_css = any(
            requirement <= region.css_tokens for requirement in css_hidden
        )
        if (
            region.role in ROLE_TAGS
            and region.tag in ROLE_TAGS[region.role]
            and not region.hidden
            and not hidden_by_css
            and region.has_content
        ):
            visible_roles[region.role].append(region)

    if len(visible_roles["summary"]) != 1:
        errors.append("dashboard requires exactly one visible summary role")
    if len(visible_roles["filters"]) < 1:
        errors.append("dashboard requires a visible filters role")
    if not 3 <= len(visible_roles["kpi"]) <= 4:
        errors.append("dashboard requires three or four visible kpi roles")
    if len(visible_roles["trend"]) + len(visible_roles["comparison"]) < 1:
        errors.append("dashboard requires a visible trend or comparison role")
    if len(visible_roles["diagnostic"]) < 1:
        errors.append("dashboard requires a visible diagnostic role")
    if len(visible_roles["actions"]) < 1:
        errors.append("dashboard requires a visible actions role")
    if len(visible_roles["summary"]) == 1 and not visible_roles["summary"][0].freshness:
        errors.append("summary requires a non-empty data-freshness value")

    for label, pattern in TECHNICAL_PATTERNS.items():
        if re.search(pattern, decoded_corpus, flags=re.IGNORECASE):
            errors.append(f"technical information present: {label}")
    for label, pattern in SECRET_PATTERNS.items():
        if re.search(pattern, decoded_corpus, flags=re.IGNORECASE):
            errors.append(f"credential material present: {label}")
    query_segments = [
        *re.split(r"\n{2,}", inspector.visible_text),
        *inspector.script_parts,
        *inspector.attribute_values,
        *inspector.comments,
    ]
    query_labels: set[str] = set()
    for segment in query_segments:
        label = contains_query_text(segment)
        if label:
            query_labels.add(label)
    for label in sorted(query_labels):
        errors.append(f"query text appears to be embedded in the HTML: {label}")

    seen: set[str] = set()
    for raw_term in forbidden_terms:
        term = raw_term.strip()
        key = term.casefold()
        if not term or key in seen:
            continue
        seen.add(key)
        if contains_dynamic_term(decoded_corpus, term):
            errors.append(f"dynamic forbidden term present: {term}")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate a single-file, offline, business-safe operations dashboard."
    )
    parser.add_argument("target", type=Path, help="One generated .html file")
    parser.add_argument(
        "--forbid",
        action="append",
        default=[],
        metavar="TERM",
        help="Technical identifier that must not occur anywhere in the HTML; repeat as needed.",
    )
    parser.add_argument(
        "--custom-theme",
        action="store_true",
        help="Skip the fixed default palette, font, blur, and hero-gradient checks after the user confirms another theme.",
    )
    args = parser.parse_args()

    if not args.target.exists():
        print(f"ERROR: target does not exist: {args.target}", file=sys.stderr)
        return 2
    if not args.target.is_file() or args.target.suffix.lower() != ".html":
        print("ERROR: target must be a single .html file", file=sys.stderr)
        return 2

    try:
        text = args.target.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        print("ERROR: HTML must be UTF-8 encoded", file=sys.stderr)
        return 2

    errors = validate_dashboard(text, args.forbid, args.custom_theme)
    if errors:
        print("Dashboard validation FAILED:")
        for error in errors:
            print(f"- {error}")
        return 1

    print("Dashboard validation passed (single offline HTML).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
