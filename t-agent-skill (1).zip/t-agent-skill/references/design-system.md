# Dashboard design system

## Principles

1. **Conclusion first:** begin with the operating conclusion, risk, or action—not a decorative title.
2. **Overview before detail:** context and KPIs precede explanations and records.
3. **Density with rhythm:** keep information dense but preserve 24 px section rhythm.
4. **Semantic consistency:** the same color, icon, and term means the same thing everywhere.
5. **Honest data:** show units, freshness, comparison windows, missing values, and uncertainty.

## Fixed default: Executive Indigo Glass

Use this preset whenever the user has not specified the corresponding colors or typography. It is derived from the user-approved `infinix-sales-dashboard-v2.html` visual reference.

### Light theme

| Role | Token | Value |
|---|---|---|
| Page base | `page-background` / `background` | `#F5F7FB` |
| Radial highlight | `page-highlight` | `#EEF2FF` |
| Inner canvas highlight | `page-highlight-soft` | `#F8FAFC` |
| Glass card | `glass-card` | `rgba(255,255,255,.78)` |
| Glass outer border | `glass-border` | `rgba(255,255,255,.65)` |
| Soft divider/grid | `border` / `soft-line` | `rgba(148,163,184,.18)` |
| Primary text | `foreground` | `#0F172A` |
| Secondary text | `muted-foreground` | `#64748B` |
| Primary / hero start | `primary` / `hero-from` | `#4F46E5` |
| Secondary / hero middle | `secondary` / `hero-via` | `#7C3AED` |
| Information / hero end | `info` / `hero-to` | `#0EA5E9` |
| Positive | `success` | `#10B981` |
| Warning | `warning` | `#F59E0B` |
| Risk / destructive | `destructive` | `#EF4444` |
| Comparison tint | `chart-context` | `#C7D2FE` |

Canvas:

```css
background: radial-gradient(circle at top left, #eef2ff 0, #f8fafc 35%, #f5f7fb 100%);
```

Glass card:

```css
background: rgba(255,255,255,.78);
backdrop-filter: blur(14px);
border: 1px solid rgba(255,255,255,.65);
box-shadow: 0 10px 30px rgba(15,23,42,.06);
```

Hero:

```css
background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 45%, #0ea5e9 100%);
```

Use white text on the hero. Normal white cards use `#0F172A` text. Use semantic status colors with text or icons, never as the only signal.

### Dark theme

| Role | Value |
|---|---|
| Background | `#0F172A` |
| Glass card | `rgba(30,41,59,.82)` |
| Muted surface | `#1E293B` |
| Foreground | `#F8FAFC` |
| Muted foreground | `#94A3B8` |
| Border | `rgba(148,163,184,.18)` |
| Primary | `#818CF8` |
| Secondary | `#A78BFA` |
| Information | `#38BDF8` |
| Positive | `#34D399` |
| Warning | `#FBBF24` |
| Destructive | `#F87171` |

### Visual character

- Main width: approximately `1280px` (`max-w-7xl`).
- Page padding: 16 px mobile, 24–32 px desktop.
- Section gap: 24 px desktop.
- Hero: 24 px radius, 24–32 px padding, white text, concise conclusion, and one high-value metric/action area.
- Content cards: 16 px radius, translucent white, 14 px blur, soft white border, and low slate shadow.
- KPI cards: four columns at desktop with restrained indigo shadow `0 10px 24px rgba(79,70,229,.10)`.
- Optional subtle grid: 24 px grid lines using `rgba(148,163,184,.07)`.
- Favor clear white space and data density. Avoid neon glow, heavy gradients on every card, thick borders, and unrelated decorative effects.

## Layout tokens

- Base spacing: `4px`.
- Steps: `4, 8, 12, 16, 24, 32, 48, 64`.
- Grid: 12 columns desktop, 8 tablet, 1 mobile.
- Common desktop splits: `8/4`, `5/7`, and `6/6`.
- Card padding: 20–24 px desktop, 16 px mobile.
- Standard radius: 16 px; hero radius: 24 px.
- Shadow: one soft card shadow; stronger only for overlays.

## Typography

- English/Latin: Inter.
- Simplified Chinese: Noto Sans SC.
- Mixed content:

```css
"Inter", "Noto Sans SC", "Source Han Sans SC", "PingFang SC",
"Microsoft YaHei", ui-sans-serif, system-ui, sans-serif
```

- Use one family stack throughout. Create hierarchy with weight, size, line height, and color.
- Keep the artifact offline: declare Inter and Noto Sans SC first, then installed CJK and system fallbacks. Do not package or download font files.
- Set `lang="zh-CN"` or `lang="en"`.
- Page title: 24–32 px, 600–700.
- Section title: 16–20 px, 600.
- KPI value: 28–36 px, 600–700, tabular numerals.
- Body: 14–16 px.
- Caption: 12–13 px with sufficient contrast.
- Apply `font-variant-numeric: tabular-nums` to metrics and tables.

## Chart palette

Ordinary series order:

1. indigo `#4F46E5`
2. violet `#7C3AED`
3. sky `#0EA5E9`
4. emerald `#10B981`
5. comparison/context `#C7D2FE`

Semantic risk colors:

- warning `#F59E0B`
- high risk `#FB923C`
- failure/destructive `#EF4444`

Rules:

- Keep recurring series colors stable.
- Use emerald, amber, orange, and red semantically in risk and action panels.
- Use sequential scales for magnitude and diverging scales only around a meaningful midpoint.
- Pair status colors with labels or icons.
- Ensure labels and axes meet contrast needs.

## Motion and accessibility

- Use 150–250 ms transitions for state changes.
- Animate opacity and transform, not layout.
- Respect `prefers-reduced-motion`.
- Target WCAG 2.2 AA, preserve visible focus, use semantic landmarks and ordered headings.
- Provide a table or concise text alternative when exact chart values affect decisions.
- Keep touch targets near 44×44 px where practical.
- Implement all visuals with semantic HTML, CSS, inline SVG, or Canvas; do not load chart or icon libraries at runtime.
