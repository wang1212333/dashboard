# Data reconciliation

Read this reference before combining file data, governed metadata, queried results, and context.

## Canonical metric contract

Create one canonical metric contract for each KPI and supporting measure:

| Field | Requirement |
|---|---|
| Business label | Confirmed user-facing name |
| Definition and formula | Governed definition by default, or a computable user override after confirmation |
| Unit and currency | Explicit and consistent, with any valid conversion documented privately |
| Direction | Whether higher, lower, or range-bound is favorable |
| Grain | Time and business-entity grain |
| Timeframe | Inclusive bounds, timezone, and freshness |
| Comparison | Prior period, target, plan, budget, or benchmark |
| Roles | Actual, target, plan, mapping, label, or reference |
| Evidence | Exact validated datasets used by cards, charts, diagnosis, and actions |

Every dashboard component uses this same contract. Do not recalculate a metric differently in a card, chart, table, or narrative.

## Relationship rules

Never join on name similarity alone. Fuse sources only when at least one of these exists:

- a governed relationship or key from verified metadata;
- a documented business key with matching type, normalization, cardinality, and grain;
- explicit user confirmation of a proposed mapping after the ambiguity is explained.

Before joining, validate uniqueness on the expected side, duplicate behavior, null keys, many-to-many risk, date alignment, timezone, and whether the relationship changes the output grain. If a relationship cannot be verified, keep the sources separate and omit conclusions that require the join.

## Value roles and precedence

Do not use a universal source priority for numbers. Assign roles:

- use the freshest validated actuals for actual performance;
- preserve targets, budgets, plans, and benchmarks as distinct comparison values;
- use mapping files only to enrich labels or business groupings;
- use metadata for definitions and relationships, never as observed values;
- use context to set the operating question and to identify hypotheses, not to manufacture evidence.

When actual values cover different periods, keep the periods explicit. When overlapping sources contain the same metric and period, compare definition, unit, currency, grain, timezone, freshness, filters, and quality before selecting anything.

## Conflicts

For a material conflict, do not average, overwrite, or silently choose. Describe the conflict in business language and stop and ask the user to resolve it.

Material conflicts include:

- incompatible metric definitions or formulas;
- mismatched units or currencies without a confirmed conversion;
- different grains that cannot be aggregated safely;
- overlapping actual values that do not reconcile;
- target or actual roles that cannot be distinguished;
- unreliable keys or many-to-many relationships;
- time bounds, timezone, or freshness that change the decision.

Record the user's resolution in the canonical contract and repeat sufficiency checks. If the scope changes after token validation, reuse the authorization without another preflight.

## Sufficiency gate

Before dashboard confirmation, verify that the fused evidence supports:

- three or four decision-relevant KPIs;
- one trend, period comparison, or dimension comparison;
- one diagnostic finding with measured evidence;
- prioritized actions traceable to visible evidence;
- consistent filters and totals across all panels;
- a defensible business timestamp.

If any required element is unsupported, query another approved source or stop. Never substitute stale examples, fabricated values, or generic advice.

## Source contribution gate

For each active source, record the exact metric, timeframe, grain, business role, and destination component. In mandatory dual-source mode, relevant uploaded data and queried business data must each contribute to at least one KPI, comparison, filter, diagnostic, detail, or action.

A metadata definition or authorization preflight alone is not a data contribution. A data-mcp result must supply validated business values, and file data must supply validated values, targets, plans, mappings, labels, or comparisons that materially change the approved dashboard.

If an active source has no valid contribution, do not silently exclude it. Stop and ask the user to correct the relationship, revise the dashboard scope, or explicitly approve a different operating mode. If a required source fails, do not use the other source as an automatic fallback.

## Business-safe presentation

Project fused data into business labels such as period, actual, target, category, and status only when those labels match the canonical contract. Keep provenance, keys, paths, filenames, source IDs, field names, formulas, queries, and technical diagnostics private.
