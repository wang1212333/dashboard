# Governed discovery and query workflow

Read this reference when metadata or data-mcp is relevant after context and file inspection.

## State contract

| State | Required action | Exit condition |
|---|---|---|
| Brief incomplete | Extract intent and constraints from relevant conversation | Operating decision and scope are explicit |
| Sources uninspected | Read every relevant attachment and classify its role | File coverage and quality are known |
| Metadata needed | Resolve one product and relevant assets | Governed definitions and relationships are known |
| Registry incomplete | Record roles and create canonical metric contracts | Sources have explicit roles and mappings |
| Native tool injection check | Inspect current callable tools and attempt the configured native query path | A callable data tool exists or fallback is required |
| Protocol fallback discovery | Use the bundled Streamable HTTP client when native exposure or handshake fails | Server tools are discovered through MCP |
| Data product confirmed | Require a real data-mcp business query | Authorization succeeds and business evidence is returned |
| Evidence incomplete | Probe bounded aggregates and reconcile sources | Sufficiency gate passes with no unresolved conflict |
| Awaiting confirmation | Present one business-language proposal | User confirms or revises it |
| Querying and fusing | Retrieve only approved datasets and apply canonical contracts | Fused results reconcile |
| Analyzing | Produce supported findings and actions | Every claim traces to visible evidence |
| Generating | Project business-safe data into one offline HTML | Artifact validation passes |

Optional states are skipped only when their observable condition is false. A confirmed data product makes metadata discovery and a real data-mcp business query mandatory. Relevant file data plus a confirmed product makes both branches mandatory.

## Product and asset selection

Use governed metadata only when a product clue, definition check, or relationship need exists:

1. search_metadata with the clue, entityType dataProduct, and a small result size.
2. Resolve credible name or displayName matches. Ask when more than one remains.
3. Call get_entity_details using the returned exact FQN and entity type.
4. Select only associated assets relevant to the business brief.
5. Call get_asset_context using exact returned identifiers.

Do not infer a product from a filename or choose an asset because its name merely looks plausible. Do not infer joins from similarly named fields.

## Conditional authorization

If a data product is confirmed, or another approved data gap selects data-mcp:

1. Request a token only if none is available.
2. Normalize a raw token to one Bearer prefix.
3. Perform the Native tool injection check. Use an already exposed data-mcp tool when available.
4. If no tool is exposed, native initialization closes, or native tools/list fails, perform Protocol fallback discovery with `scripts/data_mcp_client.py`.
5. Launch the script without command-line arguments. Pass `operation`, `token`, optional `tool`, and optional `arguments` as one JSON object through process standard input. Do not use shell echo, interpolation, temporary files, or environment variables for the token or SQL.
6. The fallback follows `initialize`, `notifications/initialized`, paginated `tools/list`, and `tools/call`. It preserves the negotiated protocol version and `Mcp-Session-Id`, supports JSON and SSE responses, and closes the session on exit when supported.
7. Validate authorization exactly once with the smallest supported authenticated read-only request. Native and fallback discovery are two transport paths within the same task authorization; never request or validate the token again after success.
8. Reuse that authorization for probes and final queries, then discard it after validated delivery or terminal failure.

An authorization probe does not count as a business-data query. Tool discovery, `list_tables`, authorization checks, and schema inspection likewise do not satisfy that requirement. Execute at least one bounded aggregate query that returns business values used by the dashboard. In dual-source mode, authorization, protocol fallback, or business query failure stops generation; do not fall back to file-only output.

Never place the credential in a command line, persistent configuration, file, generated source, query text, diagnostics, or assistant response. The current task token overrides any stale configured Authorization value only inside the fallback process and is never written back. A missing native tool is not a terminal failure. On a 401 or 403 from either path, stop without another authorization preflight.

## Query tool selection

Discover tools before every fallback operation that needs a tool schema:

- Prefer exact `list_tables` for authorized table scope, `describe_table` for one table schema, and `query_data` for business SQL.
- If the requested exact tool is absent, accept one unambiguous SQL-input tool only when its input schema contains an `sql` property and its description explicitly says read-only.
- Stop when no candidate or multiple candidates remain. Do not infer safety from a tool name alone.
- Invoke only a tool returned by the current `tools/list` result and validate `isError` before using its content.

The fallback input contract is:

~~~json
{"operation":"list_tools","token":"<current-task-token>"}
~~~

or:

~~~json
{"operation":"call_tool","token":"<current-task-token>","tool":"query_data","arguments":{"sql":"<approved-read-only-query>"}}
~~~

The JSON is process input, never a shell command literal. Success writes only the discovered tool list or tool result to stdout. Failure writes only a sanitized category: configuration failed, input validation failed, authorization failed, connection failed, protocol failed, tool discovery failed, or tool call failed.

## Read-only SQL policy

Accept one statement only. After leading whitespace and comments, it must begin with SELECT or WITH, and a CTE must end in SELECT.

Reject statements containing INSERT, UPDATE, DELETE, MERGE, UPSERT, CREATE, ALTER, DROP, TRUNCATE, GRANT, REVOKE, CALL, EXEC, COPY, LOAD, UNLOAD, a second executable statement, or SELECT *.

Every query has a justified boundary:

- use confirmed time bounds for time-based data;
- aggregate to the required KPI or chart grain;
- limit dimensions and top distributions;
- cap ranked or detail results at 1,000 rows by default;
- select only fields required by an approved canonical contract.

Probe with separate compact aggregates for freshness, coverage, cardinality, quality, and comparison availability. Do not retrieve raw sample rows merely to design the dashboard.

## Result validation

For both files and query results:

- confirm row count, output grain, timeframe, timezone, and latest timestamp;
- verify metric formulas, units, currency, and actual/target/plan roles;
- inspect null, zero, negative, duplicate, and outlier behavior;
- validate relationship keys, uniqueness, and many-to-many risk;
- reconcile totals used by multiple panels;
- distinguish a true zero from missing data;
- ensure filters can be computed from the embedded fused snapshot;
- remove sensitive or unnecessary dimensions.

If a required result is missing or inconsistent, apply [data-reconciliation.md](data-reconciliation.md). Stop for unresolved material conflicts or insufficient evidence.

## Query failure

Do not report that the current session did not expose a read-only query tool until native discovery and the protocol fallback have both failed. Report only the affected business metric, timeframe, and actionable failure category. Do not expose raw identifiers, query text, headers, endpoints, session IDs, or response payloads. Continue without the failed source only when remaining sources independently pass the confirmed sufficiency gate; mandatory dual-source mode still stops and does not fall back to file-only output.
