# Invocation guide

The minimum useful invocation is:

~~~text
Use $t-agent-skill to create an operations dashboard using this conversation
and the files I attached.
~~~

The user may also provide a data product clue and business preferences:

~~~text
Data product: Regional Performance
Primary audience: regional operations managers
Decision: identify where intervention is needed this week
Time range: current quarter, compared with the previous quarter
Uploaded file role: operating targets and region mapping
Filters: region and business category
Style: use the default theme
Deliverable: one fully offline HTML file
~~~

Conversation context, uploaded files, governed metadata, and queried data may all contribute to the same dashboard. When relevant file data and a data product coexist, the skill must use both: file completeness cannot skip metadata discovery or a real data-mcp business query. It assigns distinct roles, reconciles canonical metric contracts, verifies each source's contribution, and asks the user to confirm one proposal before final queries and generation.

A data product name is optional. A data-mcp token is requested only when database data is required and is validated once before the first data-mcp call. Do not ask the user for database, schema, table, field, query, connection, or relationship implementation names.
