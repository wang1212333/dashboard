# Behavior examples

## Files, metadata, and queried data coexist

The user asks for a regional performance dashboard, uploads a planning spreadsheet, and names a governed data product.

The skill:

1. Extracts the regional intervention decision, timeframe, and style from context.
2. Reads the spreadsheet as targets, plan values, and business mappings.
3. Resolves the named product and verifies metric definitions, grain, and relationships.
4. Enters mandatory dual-source mode because relevant file data and a confirmed product coexist, then requests and validates a token once regardless of file completeness.
5. Queries bounded actual business data; the authorization probe alone does not count. It reconciles the results with file targets and stops for any material conflict.
6. Presents one business-only dashboard proposal and waits for confirmation.
7. Reuses the authorization for final datasets, produces gap analysis and prioritized actions, and generates one offline HTML.

The page shows business actuals, targets, gaps, findings, and actions. It does not reveal filenames, source registry details, metadata, query tooling, or technical identifiers.

Both branches must materially contribute: file targets or mappings affect a comparison, filter, or action, while queried values affect actual KPIs, trends, diagnostics, or details. If either branch cannot contribute, the skill asks the user to correct or rescope it instead of silently generating from the other branch.

## File-only evidence

The user uploads a structured file with verified actuals, targets, dates, dimensions, and enough history for analysis. No product clue or governance need exists.

Inspect and validate the file, build canonical metric contracts, ask for dashboard confirmation, and generate from the file. Do not call metadata, request a token, or query data-mcp.

## Product-only evidence

The user names a data product without uploading files. Resolve its governed scope first. If real metric values are needed, request a token only before the first data-mcp call, validate it once, probe bounded aggregates, and continue through reconciliation and confirmation.

## Complementary roles

A file may provide targets, budgets, plans, manual categories, or mappings while data-mcp provides actual performance. Preserve those roles rather than choosing one source. Use verified metadata definitions and relationships to establish the canonical model.

## Conflicting actuals

When a file and query result contain different actual values for the same canonical metric and period, compare definitions, units, currency, grain, timezone, freshness, and filters. If the difference remains material, explain it in business language and wait for the user's resolution. Never average or overwrite the values.

## Unverified relationship

When source columns have similar names but no governed relationship, documented key, or confirmed mapping, keep the sources separate. Omit panels and conclusions that require the join.

## Missing authorization or source failure

If data-mcp is required and no token is available, ask for it and stop before the first call. In dual-source mode, a required file, metadata branch, authorization, asset lookup, or business query failure stops generation; never downgrade to file-only output.

## Query tool not injected

When the configured data service is not present in the current callable tool list, do not tell the user that no read-only query tool exists. Run the bundled protocol fallback through process standard input, discover the live server tools, and call the verified read-only query tool. Ask the user to intervene only when both the native path and fallback fail, or when authorization or tool selection is ambiguous.

## Scope revision

When the user changes a KPI, timeframe, mapping, or operating decision after the proposal, update the canonical contracts and rerun reconciliation and sufficiency. Reuse an already validated token without another preflight.
