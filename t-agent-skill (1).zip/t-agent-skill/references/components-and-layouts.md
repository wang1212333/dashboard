# Operations dashboard components and layout

## Default operating cockpit

1. A 12-column summary surface with the confirmed business conclusion, timeframe, freshness, and at most one primary action.
2. A full-width filter region with visible labels, active state, and reset.
3. Three or four KPI cards showing value, unit, comparison period, direction, and business context.
4. An 8-column trend or comparison panel paired with a 4-column diagnostic or target panel.
5. A full-width operating-action section, followed by a ranked detail table only when it improves the decision.

Use only panels supported by confirmed definitions and real query results. Fewer meaningful panels are better than unrelated filler.

## Required component contracts

### Summary

Use data-dashboard-role="summary" and a data-freshness timestamp. Include title, range, update time, evidence-based conclusion, and one next action when justified.

### Filters

Use data-dashboard-role="filters". Filters operate only on embedded data. Provide visible labels, sensible defaults, active state, reset, keyboard access, and a no-results message.

### KPI

Use data-dashboard-role="kpi" three or four times. Include label, formatted value/unit, comparison value and period, and favorable/unfavorable context. Never rely on color alone.

### Trend or comparison

Use data-dashboard-role="trend" for change over time or data-dashboard-role="comparison" for category comparison. Include unit, timeframe, accessible exact values, and a concise conclusion.

### Diagnostic

Use data-dashboard-role="diagnostic". Explain what changed, the comparison basis and magnitude, where impact is concentrated, and which measured contributors or signals relate to the primary decision. Do not imply causality unless the data supports it.

### Business actions

Use data-dashboard-role="actions". This region is mandatory and cannot be replaced by a detail table. Each prioritized action includes labeled Evidence, Impact scope, Priority, Next step, Expected direction, and Follow-up. Tie every recommendation to a visible metric, segment, trend, anomaly, or target gap; omit generic advice.

### Detail

Use data-dashboard-role="detail" for optional ranked exact lookup. Detail rows use business labels, aligned values, stable in-memory keys, and responsive disclosure.

## Visualization choice

| Business question | Offline default |
|---|---|
| Change over time | Inline SVG line or area line |
| Category comparison | Sorted horizontal bars |
| Composition | Stacked bars; donut only for five or fewer parts |
| Distance to target | Bullet or progress view |
| Exact value or status | Semantic table |
| Priority interventions | Ranked action list |

Avoid dual axes, 3D charts, rainbow palettes, decorative gauges, and motion that changes layout.

## Responsive reading order

- At 1280 px and wider, use the full 12-column composition.
- From 768 to 1279 px, adapt to 8 columns without squeezing charts below useful width.
- Below 768 px, use one reading column and reduce tables to priority fields plus row details.
- Keep labels readable and never solve width by shrinking text or allowing page-level horizontal scroll.
