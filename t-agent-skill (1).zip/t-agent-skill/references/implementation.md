# Single-file HTML implementation

Read this reference only after the dashboard proposal is confirmed and all approved file and query results have been reconciled through the canonical business model.

## Artifact boundary

Create exactly one .html file. It must work when opened directly with no network connection.

- Put all CSS in inline style elements.
- Put all JavaScript and the business-safe data snapshot in inline script elements.
- Use semantic HTML plus inline SVG, Canvas, or CSS for charts.
- Do not use script src, stylesheet links, imports, CDNs, remote URLs, web fonts, images, iframes, fetch, XMLHttpRequest, WebSocket, EventSource, or browser-side service calls.
- Do not create companion CSS, JavaScript, JSON, image, map, or font files.

## Stable structure contract

The validator uses these attributes. Include each required role exactly where it describes the visible region:

~~~html
<header data-dashboard-role="summary" data-freshness="2026-08-22T08:00:00+08:00">
  <!-- Business title, timeframe, freshness, conclusion -->
</header>
<main>
  <section data-dashboard-role="filters"></section>
  <article data-dashboard-role="kpi"></article>
  <article data-dashboard-role="kpi"></article>
  <article data-dashboard-role="kpi"></article>
  <section data-dashboard-role="trend"></section>
  <section data-dashboard-role="diagnostic"></section>
  <section data-dashboard-role="actions"></section>
  <section data-dashboard-role="detail"></section> <!-- Optional -->
</main>
~~~

Use three or four kpi roles. Use comparison instead of trend when there is no time series. Diagnostic and actions are both mandatory. Detail is optional and never replaces actions.

## Embedded snapshot

Project fused results into a small presentation model before serialization. Preserve approved business roles such as actual, target, plan, benchmark, category, and status. The HTML contains only approved business keys and values; it contains no undisplayed raw rows, source registry, provenance, mappings, paths, filenames, source identifiers, query text, credentials, or internal error payloads.

Escape embedded strings for their HTML and JavaScript contexts. Prefer a JSON script block or a literal object with no executable user-provided content. Treat every returned value as data, never markup or code.

The browser may filter and recompute visible totals from the embedded snapshot. It must not refresh from a service. Show the snapshot's business timestamp as "数据更新至" or equivalent, without naming the source platform.

## Offline visualization

- Use inline SVG for accessible line, bar, progress, and compact distribution views.
- Use Canvas only when density justifies it, and provide an adjacent text summary or accessible table.
- Give charts a business title, unit, timeframe, legend/direct labels, tooltip or exact-value alternative, and empty-filter state.
- Keep recurring series colors stable and risk colors semantic.
- Do not embed third-party library source into the file merely to satisfy the offline rule.

## Responsive behavior

- Use a 12-column desktop grid, an 8-column tablet adaptation, and one reading column below 768 px.
- Keep chart containers dimensionally stable with min-height, aspect ratio, or fixed grid tracks.
- Reduce table columns on narrow screens and expose row details without page-level horizontal scrolling.
- Include media rules for mobile, dark mode, and prefers-reduced-motion.
- Keep visible focus and keyboard-operable filters, theme controls, tooltips, and row details.

## Technical-information scrub

Scrub the complete source, not only visible text. Technical identifiers can leak through:

- local paths, original filenames, sheet names, and document metadata;
- source-registry labels, provenance, join keys, and mapping details;
- comments and element IDs;
- JavaScript variable names and embedded object keys;
- titles, tooltips, aria labels, and data attributes;
- error messages and empty states;
- filenames, URLs, and source notes.

Use neutral component IDs such as trendPanel and business data keys. Do not include a hidden diagnostics panel, source inventory, provenance view, mapping view, query template, lineage view, or implementation disclosure.

## Validation

Run the validator with every discovered identifier:

~~~bash
python scripts/validate_dashboard_theme.py output.html \
  --forbid <tool-name> --forbid <endpoint-host> \
  --forbid <source-path-or-filename> --forbid <private-source-label> \
  --forbid <connection-or-service-name> --forbid <database-name> \
  --forbid <schema-name> --forbid <table-or-field-name-or-fqn>
~~~

Append `--custom-theme` only when the user explicitly confirmed a non-default visual theme. The flag does not relax semantic variables, offline behavior, dashboard structure, privacy, responsiveness, dark mode, or reduced-motion requirements.

Then inspect the rendered page at 375, 768, 1024, and 1440 px, at 200% zoom, in light/dark modes, with keyboard-only input, reduced motion, long labels, empty filters, zeros, negatives, and nulls.
