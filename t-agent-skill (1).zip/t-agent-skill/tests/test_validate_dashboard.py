from __future__ import annotations

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
VALIDATOR = SKILL_ROOT / "scripts" / "validate_dashboard_theme.py"


def valid_dashboard_html(extra_head: str = "", extra_body: str = "") -> str:
    kpis = "".join(
        f'<article data-dashboard-role="kpi"><h2>指标 {index}</h2><strong>{index * 10}</strong></article>'
        for index in range(1, 5)
    )
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>经营概览</title>
  {extra_head}
  <style>
    :root {{
      --primary: #4f46e5; --secondary: #7c3aed; --info: #0ea5e9;
      --success: #10b981; --warning: #f59e0b; --destructive: #ef4444;
      --background: #f5f7fb; --foreground: #0f172a; --muted: #64748b;
      --border: rgba(148,163,184,.18); --glass-card: rgba(255,255,255,.78);
      --glass-border: rgba(255,255,255,.65); --hero-from: #4f46e5;
      --hero-via: #7c3aed; --hero-to: #0ea5e9;
    }}
    body {{
      margin: 0; color: var(--foreground);
      font-family: "Inter", "Noto Sans SC", "Microsoft YaHei", sans-serif;
      background: radial-gradient(circle at top left, #eef2ff 0, #f8fafc 35%, #f5f7fb 100%);
    }}
    header {{ background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 45%, #0ea5e9 100%); }}
    section, article {{ background: var(--glass-card); backdrop-filter: blur(14px); }}
    @media (max-width: 768px) {{ main {{ display: block; }} }}
    @media (prefers-color-scheme: dark) {{ body {{ background: #0f172a; color: #f8fafc; }} }}
    @media (prefers-reduced-motion: reduce) {{ * {{ animation: none !important; }} }}
  </style>
</head>
<body>
  <header data-dashboard-role="summary" data-freshness="2026-08-22">经营结论</header>
  <main>
    <section data-dashboard-role="filters">筛选条件</section>
    {kpis}
    <section data-dashboard-role="trend">趋势</section>
    <section data-dashboard-role="diagnostic">经营诊断</section>
    <section data-dashboard-role="actions">行动建议</section>
    {extra_body}
  </main>
  <script>document.documentElement.dataset.ready = "true";</script>
</body>
</html>
"""


class DashboardValidatorTests(unittest.TestCase):
    def run_validator(self, html: str, *args: str, target_directory: bool = False):
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            target = root if target_directory else root / "dashboard.html"
            file_path = root / "dashboard.html"
            file_path.write_text(html, encoding="utf-8")
            return subprocess.run(
                [sys.executable, str(VALIDATOR), str(target), *args],
                capture_output=True,
                text=True,
                encoding="utf-8",
                check=False,
            )

    def test_accepts_complete_offline_single_html_dashboard(self):
        result = self.run_validator(valid_dashboard_html())

        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("validation passed", result.stdout.lower())

    def test_rejects_external_script_dependency(self):
        result = self.run_validator(
            valid_dashboard_html(extra_head='<script src="https://example.com/chart.js"></script>')
        )

        self.assertEqual(result.returncode, 1)
        self.assertIn("external", result.stdout.lower())

    def test_rejects_fixed_technical_information(self):
        result = self.run_validator(
            valid_dashboard_html(extra_body="<p>data-mcp 待接入，当前为演示数据</p>")
        )

        self.assertEqual(result.returncode, 1)
        self.assertIn("technical", result.stdout.lower())

    def test_rejects_runtime_asset_identifier(self):
        identifier = "warehouse.finance.secret_table"
        result = self.run_validator(
            valid_dashboard_html(extra_body=f"<p>{identifier}</p>"),
            "--forbid",
            identifier,
        )

        self.assertEqual(result.returncode, 1)
        self.assertIn("dynamic forbidden term", result.stdout.lower())

    def test_rejects_directory_instead_of_one_html_file(self):
        result = self.run_validator(valid_dashboard_html(), target_directory=True)

        self.assertEqual(result.returncode, 2)
        self.assertIn("single .html file", result.stderr.lower())

    def test_rejects_missing_operating_dashboard_structure(self):
        html = valid_dashboard_html().replace('data-dashboard-role="diagnostic"', "")
        result = self.run_validator(html)

        self.assertEqual(result.returncode, 1)
        self.assertIn("diagnostic", result.stdout.lower())

    def test_rejects_detail_without_business_actions(self):
        html = valid_dashboard_html().replace(
            '<section data-dashboard-role="actions">行动建议</section>',
            '<section data-dashboard-role="detail">经营明细</section>',
        )
        result = self.run_validator(html)

        self.assertEqual(result.returncode, 1)
        self.assertIn("actions", result.stdout.lower())

    def test_rejects_encoded_query_and_dynamic_identifiers(self):
        result = self.run_validator(
            valid_dashboard_html(
                extra_body="<p>S&#69;LECT customer&#95;id FROM ord&#101;rs</p>"
            ),
            "--forbid",
            "customer_id",
            "--forbid",
            "orders",
        )

        self.assertEqual(result.returncode, 1)
        self.assertIn("query text", result.stdout.lower())
        self.assertIn("dynamic forbidden term", result.stdout.lower())

    def test_rejects_non_select_query_text(self):
        statements = (
            "UPDATE customers SET tier = 1",
            "INSERT INTO customers (tier) VALUES (1)",
            "DELETE FROM customers WHERE tier = 1",
            "DROP TABLE customers",
            "CALL refresh_metrics()",
        )
        for statement in statements:
            with self.subTest(statement=statement):
                result = self.run_validator(
                    valid_dashboard_html(extra_body=f"<pre>{statement}</pre>")
                )
                self.assertEqual(result.returncode, 1)
                self.assertIn("query text", result.stdout.lower())

    def test_rejects_local_and_runtime_resource_dependencies(self):
        dependencies = (
            '<img src="support.png" alt="support">',
            (
                '<img srcset="data:image/png;base64,AAAA 1x, support.png 2x" '
                'alt="support">'
            ),
            '<script src="data:text/javascript,alert(1)"></script>',
            '<iframe src="report.html"></iframe>',
            '<form action="save"><button>保存</button></form>',
            '<style>.logo { background-image: url(logo.png); }</style>',
            (
                '<script>new Image().src = '
                '"https://example.com/pixel.png";</script>'
            ),
        )
        for dependency in dependencies:
            with self.subTest(dependency=dependency):
                result = self.run_validator(
                    valid_dashboard_html(extra_body=dependency)
                )
                self.assertEqual(result.returncode, 1)
                self.assertIn("external", result.stdout.lower())

    def test_accepts_inline_svg_namespace(self):
        result = self.run_validator(
            valid_dashboard_html(
                extra_body=(
                    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10" '
                    'aria-label="趋势图"><path d="M0 10 L10 0"></path></svg>'
                )
            )
        )

        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_rejects_commented_or_hidden_required_regions(self):
        original = (
            '<section data-dashboard-role="diagnostic">经营诊断</section>'
        )
        replacements = (
            f"<!-- {original} -->",
            '<section hidden data-dashboard-role="diagnostic">经营诊断</section>',
            (
                '<section aria-hidden="true" data-dashboard-role="diagnostic">'
                "经营诊断</section>"
            ),
            (
                '<style>.concealed { display: none; }</style>'
                '<section class="concealed" data-dashboard-role="diagnostic">'
                "经营诊断</section>"
            ),
        )
        for replacement in replacements:
            with self.subTest(replacement=replacement):
                result = self.run_validator(
                    valid_dashboard_html().replace(original, replacement)
                )
                self.assertEqual(result.returncode, 1)
                self.assertIn("diagnostic", result.stdout.lower())

    def test_accepts_confirmed_custom_theme_flag(self):
        custom = (
            valid_dashboard_html()
            .replace("#4f46e5", "#005f73")
            .replace("#7c3aed", "#9b2226")
            .replace("#0ea5e9", "#0a9396")
            .replace("#10b981", "#2a9d8f")
            .replace("#f5f7fb", "#f7f7f2")
            .replace("#0f172a", "#1f2933")
            .replace('"Inter", "Noto Sans SC", ', "")
            .replace("blur(14px)", "blur(8px)")
            .replace("linear-gradient(135deg", "linear-gradient(120deg")
        )

        without_flag = self.run_validator(custom)
        with_flag = self.run_validator(custom, "--custom-theme")

        self.assertEqual(without_flag.returncode, 1)
        self.assertEqual(
            with_flag.returncode, 0, with_flag.stdout + with_flag.stderr
        )

    def test_rejects_select_without_from_and_long_query_text(self):
        statements = (
            "SELECT 1",
            "SELECT/**/1",
            "SELECT 1 " + ("x" * 2101),
            "SELECT customer_id",
            "UPDATE/**/customers/**/SET tier = 1",
        )
        for statement in statements:
            with self.subTest(statement=statement[:40]):
                result = self.run_validator(
                    valid_dashboard_html(extra_body=f"<pre>{statement}</pre>")
                )
                self.assertEqual(result.returncode, 1)
                self.assertIn("query text", result.stdout.lower())

    def test_accepts_ordinary_select_instruction(self):
        result = self.run_validator(
            valid_dashboard_html(
                extra_body="<p>Select a region to review its performance.</p>"
            )
        )

        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_rejects_css_resource_created_by_script(self):
        result = self.run_validator(
            valid_dashboard_html(
                extra_body=(
                    '<script>document.body.style.backgroundImage = '
                    '"url(support.png)";</script>'
                )
            )
        )

        self.assertEqual(result.returncode, 1)
        self.assertIn("external", result.stdout.lower())


if __name__ == "__main__":
    unittest.main()
