from __future__ import annotations

import unittest
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]


class SkillWorkflowContractTests(unittest.TestCase):
    def setUp(self):
        self.skill = (SKILL_ROOT / "SKILL.md").read_text(encoding="utf-8")

    def test_context_and_files_are_inspected_before_optional_tools(self):
        brief = self.skill.index("### 1. Build the business brief")
        inventory = self.skill.index("### 2. Inventory and inspect sources")
        metadata = self.skill.index("### 3. Resolve governed metadata when relevant")
        authorization = self.skill.index("### 5. Authorize data queries when needed")

        self.assertLess(brief, inventory)
        self.assertLess(inventory, metadata)
        self.assertLess(metadata, authorization)

    def test_product_name_and_token_are_conditional_inputs(self):
        required_input = self.skill.split("## Required workflow", 1)[0]

        self.assertIn("conversation context or uploaded files", required_input)
        self.assertIn("data product name and data-mcp token are conditional", required_input)
        self.assertNotIn(
            "must provide a data product name and a data-mcp token", required_input
        )

    def test_sources_can_coexist_and_have_private_registry(self):
        routing = (SKILL_ROOT / "references" / "source-routing.md").read_text(
            encoding="utf-8"
        )

        for source in (
            "Conversation context",
            "Uploaded files",
            "OpenMetadata",
            "data-mcp",
        ):
            self.assertIn(source, routing)
        self.assertIn("may coexist", routing)
        self.assertIn("private source registry", routing)
        self.assertIn("must not appear in the final HTML", routing)

    def test_file_and_confirmed_product_force_complete_dual_source_mode(self):
        routing = (SKILL_ROOT / "references" / "source-routing.md").read_text(
            encoding="utf-8"
        )

        self.assertIn(
            "When relevant uploaded file data and a confirmed data product coexist, "
            "dual-source mode is mandatory",
            routing,
        )
        self.assertIn(
            "File sufficiency must not skip OpenMetadata or data-mcp", routing
        )
        self.assertIn(
            "File-only mode is allowed only when no credible data product clue exists",
            routing,
        )

    def test_confirmed_product_requires_metadata_and_real_business_query(self):
        for tool_call in (
            "search_metadata",
            "get_entity_details",
            "get_asset_context",
        ):
            self.assertIn(tool_call, self.skill)
        self.assertIn(
            "A confirmed data product always requires data-mcp", self.skill
        )
        self.assertIn(
            "authorization preflight does not count as a business-data query",
            self.skill,
        )
        self.assertIn("at least one bounded business-data query", self.skill)

    def test_dual_source_contribution_gate_and_no_file_only_fallback(self):
        routing = (SKILL_ROOT / "references" / "source-routing.md").read_text(
            encoding="utf-8"
        )
        reconciliation = (
            SKILL_ROOT / "references" / "data-reconciliation.md"
        ).read_text(encoding="utf-8")

        self.assertIn("Source contribution gate", reconciliation)
        self.assertIn(
            "at least one KPI, comparison, filter, diagnostic, detail, or action",
            reconciliation,
        )
        self.assertIn("do not silently exclude it", reconciliation)
        self.assertIn("do not fall back to a file-only dashboard", routing)

    def test_reconciliation_requires_verified_relationships_and_conflict_confirmation(
        self,
    ):
        reconciliation = (
            SKILL_ROOT / "references" / "data-reconciliation.md"
        ).read_text(encoding="utf-8")

        self.assertIn("Canonical metric contract", reconciliation)
        self.assertIn("Never join on name similarity alone", reconciliation)
        self.assertIn(
            "do not average, overwrite, or silently choose", reconciliation
        )
        self.assertIn("stop and ask the user to resolve it", reconciliation)

    def test_authorization_is_conditional_and_validated_once(self):
        self.assertIn("Only when data-mcp is required", self.skill)
        self.assertIn("validate it exactly once", self.skill)
        self.assertIn("reuse the same in-memory authorization", self.skill)
        self.assertIn("do not request a token", self.skill.lower())

    def test_missing_native_query_tool_requires_protocol_fallback(self):
        workflow = (SKILL_ROOT / "references" / "data-workflow.md").read_text(
            encoding="utf-8"
        )

        self.assertIn("Native tool injection check", workflow)
        self.assertIn("Protocol fallback discovery", workflow)
        self.assertIn("scripts/data_mcp_client.py", self.skill)
        self.assertIn(
            "must not stop merely because the current session did not expose",
            self.skill,
        )
        self.assertIn("initialize", workflow)
        self.assertIn("notifications/initialized", workflow)
        self.assertIn("tools/list", workflow)
        self.assertIn("tools/call", workflow)

    def test_fallback_preserves_authorization_and_query_contracts(self):
        workflow = (SKILL_ROOT / "references" / "data-workflow.md").read_text(
            encoding="utf-8"
        )

        self.assertIn("list_tables", workflow)
        self.assertIn("describe_table", workflow)
        self.assertIn("query_data", workflow)
        self.assertIn("one unambiguous SQL-input tool", workflow)
        self.assertIn("standard input", workflow)
        self.assertIn("does not count as a business-data query", workflow)
        self.assertIn("do not fall back to file-only output", workflow)

    def test_dashboard_requires_analysis_and_business_actions(self):
        components = (
            SKILL_ROOT / "references" / "components-and-layouts.md"
        ).read_text(encoding="utf-8")

        self.assertIn("a diagnostic or risk analysis panel", self.skill)
        self.assertIn("a dedicated operating-action section", self.skill)
        self.assertIn("### Business actions", components)
        self.assertIn("Evidence", components)
        self.assertIn("Priority", components)
        self.assertIn("Next step", components)

    def test_feishu_logic_is_absent(self):
        corpus = "\n".join(
            path.read_text(encoding="utf-8") for path in SKILL_ROOT.rglob("*.md")
        ).lower()

        self.assertNotIn("feishu", corpus)
        self.assertNotIn("飞书", corpus)


if __name__ == "__main__":
    unittest.main()
