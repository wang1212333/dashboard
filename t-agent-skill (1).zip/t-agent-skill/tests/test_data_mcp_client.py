from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
CLIENT = SKILL_ROOT / "scripts" / "data_mcp_client.py"


class MCPHandler(BaseHTTPRequestHandler):
    mode = "json"
    requests: list[dict[str, object]] = []
    tools_pages: list[dict[str, object]] = []
    call_result: dict[str, object] = {
        "content": [{"type": "text", "text": "business result"}],
        "isError": False,
    }
    fail_status: int | None = None
    malformed = False

    def log_message(self, *_args: object) -> None:
        return

    def _write_jsonrpc(self, message: dict[str, object], session: bool = False) -> None:
        if self.malformed:
            body = b"not-json"
            content_type = "application/json"
        elif self.mode == "sse":
            body = ("data: " + json.dumps(message) + "\n\n").encode()
            content_type = "text/event-stream"
        else:
            body = json.dumps(message).encode()
            content_type = "application/json"
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        if session:
            self.send_header("Mcp-Session-Id", "session-123")
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        try:
            message = json.loads(raw)
        except json.JSONDecodeError:
            message = {}
        self.requests.append(
            {
                "message": message,
                "authorization": self.headers.get("Authorization"),
                "session": self.headers.get("Mcp-Session-Id"),
                "protocol": self.headers.get("MCP-Protocol-Version"),
            }
        )

        if self.fail_status:
            self.send_response(self.fail_status)
            self.end_headers()
            return

        method = message.get("method")
        if method == "initialize":
            self._write_jsonrpc(
                {
                    "jsonrpc": "2.0",
                    "id": message["id"],
                    "result": {
                        "protocolVersion": "2025-06-18",
                        "capabilities": {"tools": {}},
                        "serverInfo": {"name": "test", "version": "1"},
                    },
                },
                session=True,
            )
        elif method == "notifications/initialized":
            self.send_response(202)
            self.end_headers()
        elif method == "tools/list":
            cursor = message.get("params", {}).get("cursor")
            page = 1 if cursor else 0
            result = self.tools_pages[page]
            self._write_jsonrpc(
                {"jsonrpc": "2.0", "id": message["id"], "result": result}
            )
        elif method == "tools/call":
            self._write_jsonrpc(
                {
                    "jsonrpc": "2.0",
                    "id": message["id"],
                    "result": self.call_result,
                }
            )
        else:
            self._write_jsonrpc(
                {
                    "jsonrpc": "2.0",
                    "id": message.get("id", 0),
                    "error": {"code": -32601, "message": "unknown"},
                }
            )


class DataMCPClientTests(unittest.TestCase):
    def setUp(self) -> None:
        MCPHandler.mode = "json"
        MCPHandler.requests = []
        MCPHandler.fail_status = None
        MCPHandler.malformed = False
        MCPHandler.call_result = {
            "content": [{"type": "text", "text": "business result"}],
            "isError": False,
        }
        MCPHandler.tools_pages = [
            {
                "tools": [
                    {
                        "name": "list_tables",
                        "description": "List authorized tables",
                        "inputSchema": {"type": "object", "properties": {}},
                    },
                    {
                        "name": "describe_table",
                        "description": "Describe one table",
                        "inputSchema": {
                            "type": "object",
                            "properties": {"table_name": {"type": "string"}},
                            "required": ["table_name"],
                        },
                    },
                ],
                "nextCursor": "page-2",
            },
            {
                "tools": [
                    {
                        "name": "query_data",
                        "description": "Read-only SQL query",
                        "inputSchema": {
                            "type": "object",
                            "properties": {"sql": {"type": "string"}},
                            "required": ["sql"],
                        },
                    }
                ]
            },
        ]
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), MCPHandler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.temporary = tempfile.TemporaryDirectory()
        root = Path(self.temporary.name)
        (root / "config.toml").write_text(
            "[mcp_servers.\"data-mcp\"]\n"
            f'url = "http://127.0.0.1:{self.server.server_port}/mcp"\n'
            'http_headers = { Authorization = "Bearer stale-token" }\n',
            encoding="utf-8",
        )
        self.env = os.environ.copy()
        self.env["CODEX_HOME"] = str(root)
        self.env["PYTHONIOENCODING"] = "utf-8"

    def tearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.temporary.cleanup()

    def run_client(self, request: dict[str, object]) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, str(CLIENT)],
            input=json.dumps(request),
            capture_output=True,
            text=True,
            encoding="utf-8",
            env=self.env,
            check=False,
        )

    def test_lists_paginated_tools_and_carries_session_headers(self):
        result = self.run_client({"operation": "list_tools", "token": "fresh-token"})

        self.assertEqual(result.returncode, 0, result.stderr)
        names = [tool["name"] for tool in json.loads(result.stdout)["tools"]]
        self.assertEqual(names, ["list_tables", "describe_table", "query_data"])
        self.assertTrue(
            all(item["authorization"] == "Bearer fresh-token" for item in MCPHandler.requests)
        )
        for item in MCPHandler.requests[1:]:
            self.assertEqual(item["session"], "session-123")
            self.assertEqual(item["protocol"], "2025-06-18")

    def test_supports_sse_responses_and_calls_exact_tool(self):
        MCPHandler.mode = "sse"
        result = self.run_client(
            {
                "operation": "call_tool",
                "token": "fresh-token",
                "tool": "query_data",
                "arguments": {"sql": "SELECT count(1) FROM approved_table"},
            }
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["content"][0]["text"], "business result")
        call = [r["message"] for r in MCPHandler.requests if r["message"].get("method") == "tools/call"]
        self.assertEqual(call[0]["params"]["name"], "query_data")

    def test_writes_unicode_results_as_utf8_on_windows(self):
        MCPHandler.call_result = {
            "content": [{"type": "text", "text": "业务结果 • 已完成"}],
            "isError": False,
        }
        env = self.env.copy()
        env.pop("PYTHONIOENCODING", None)
        env["PYTHONUTF8"] = "0"

        result = subprocess.run(
            [sys.executable, str(CLIENT)],
            input=json.dumps(
                {
                    "operation": "call_tool",
                    "token": "fresh-token",
                    "tool": "list_tables",
                    "arguments": {},
                }
            ),
            capture_output=True,
            text=True,
            encoding="utf-8",
            env=env,
            check=False,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["content"][0]["text"], "业务结果 • 已完成")

    def test_selects_one_unambiguous_sql_tool_when_requested_name_is_absent(self):
        MCPHandler.tools_pages = [
            {
                "tools": [
                    {
                        "name": "readonly_query",
                        "description": "Execute a read-only query",
                        "inputSchema": {
                            "type": "object",
                            "properties": {"sql": {"type": "string"}},
                            "required": ["sql"],
                        },
                    }
                ]
            }
        ]
        result = self.run_client(
            {
                "operation": "call_tool",
                "token": "fresh-token",
                "tool": "query_data",
                "arguments": {"sql": "SELECT count(1) FROM approved_table"},
            }
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        call = [r["message"] for r in MCPHandler.requests if r["message"].get("method") == "tools/call"]
        self.assertEqual(call[0]["params"]["name"], "readonly_query")

    def test_rejects_ambiguous_sql_tools_without_leaking_input(self):
        secret = "secret-token-value"
        statement = "SELECT sensitive_value FROM private_table"
        tool = {
            "description": "Read-only SQL query",
            "inputSchema": {
                "type": "object",
                "properties": {"sql": {"type": "string"}},
                "required": ["sql"],
            },
        }
        MCPHandler.tools_pages = [
            {"tools": [{"name": "query_one", **tool}, {"name": "query_two", **tool}]}
        ]
        result = self.run_client(
            {
                "operation": "call_tool",
                "token": secret,
                "tool": "query_data",
                "arguments": {"sql": statement},
            }
        )

        self.assertEqual(result.returncode, 1)
        combined = result.stdout + result.stderr
        self.assertIn("tool discovery failed", combined.lower())
        self.assertNotIn(secret, combined)
        self.assertNotIn(statement, combined)
        self.assertNotIn(str(self.server.server_port), combined)

    def test_sanitizes_authorization_protocol_and_tool_failures(self):
        cases = (
            (401, False, False, "authorization failed"),
            (None, True, False, "protocol failed"),
            (None, False, True, "tool call failed"),
        )
        for status, malformed, tool_error, category in cases:
            with self.subTest(category=category):
                MCPHandler.requests = []
                MCPHandler.fail_status = status
                MCPHandler.malformed = malformed
                MCPHandler.call_result = {
                    "content": [{"type": "text", "text": "internal detail"}],
                    "isError": tool_error,
                }
                result = self.run_client(
                    {
                        "operation": "call_tool",
                        "token": "secret-token-value",
                        "tool": "query_data",
                        "arguments": {"sql": "SELECT 1 FROM private_table"},
                    }
                )
                self.assertEqual(result.returncode, 1)
                combined = result.stdout + result.stderr
                self.assertIn(category, combined.lower())
                self.assertNotIn("secret-token-value", combined)
                self.assertNotIn("private_table", combined)
                MCPHandler.fail_status = None
                MCPHandler.malformed = False
