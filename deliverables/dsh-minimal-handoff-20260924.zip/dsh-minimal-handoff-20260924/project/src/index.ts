import { registerWorkbenchFailureGuard } from './workbench-failure-guard.js'
import { LiveService } from './live-dashboard/service.js'
import { startLiveShareServer } from './live-dashboard/sharing.js'
import type { Context } from '@deepseek-ai/cordis'
import { resolve } from 'node:path'
import type {} from '@deepseek-ai/dsh-host-webserver'
import type {} from '@deepseek-ai/dsh-llm'
import { DshModelAnalyzer } from './ai/dsh-model-analyzer.js'
import { createKnowledgeLibrary } from './library/factory.js'
import type { IdentityProvider } from './library/ports.js'
import type { WorkbenchPluginConfig } from './service.js'
import { registerWorkbenchTools } from './tools.js'
import { makeWorkbenchWebRoutes } from './web-ui/host-routes.js'
import { createWorkbenchTracer } from './observability/phoenix.js'
import { HeadlessDashboardAgentService } from './headless-dashboard-agent.js'
import { NativeWorkbenchSessions } from './native-workbench-sessions.js'
import { registerNativeTaskContext } from './native-task-context.js'

export const name = 'dsh-workbench'
export const inject = ['tools', 'webServer', 'llm', 'agents']

/** DSH bundle entry point: Harness loads this after the tool runtime is ready. */
export function apply(ctx: Context, config: WorkbenchPluginConfig = {}): void {
  register(ctx, config)
}

/** Production bootstrap calls this with identity resolved from trusted host session middleware. */
export function applyWithIdentity(ctx: Context, config: WorkbenchPluginConfig, identity: IdentityProvider): void {
  register(ctx, config, identity)
}

function register(ctx: Context, config: WorkbenchPluginConfig, identity?: IdentityProvider): void {
  const library = createKnowledgeLibrary(config, identity)
  const tracer = createWorkbenchTracer()
  const modelAnalyzer = new DshModelAnalyzer(ctx, tracer)
  const uploadRoot = config.libraryRoot ?? './dsh-workbench-library'
  registerWorkbenchFailureGuard(ctx)
  const nativeSessions = new NativeWorkbenchSessions(uploadRoot)
  registerNativeTaskContext(ctx, nativeSessions, uploadRoot)
  const headlessAgents = new HeadlessDashboardAgentService(ctx, resolve(uploadRoot), nativeSessions)
  const live = new LiveService(resolve(uploadRoot), library)
  registerWorkbenchTools(ctx, library, nativeSessions, live)
  ctx.effect(() => {
    const sharingServer = startLiveShareServer(live)
    const disposers = makeWorkbenchWebRoutes(library, modelAnalyzer, uploadRoot, headlessAgents, nativeSessions, live).map(route => ctx.webServer.register(route))
    return () => { sharingServer.close(); disposers.forEach(dispose => dispose()); void modelAnalyzer.shutdownTracing() }
  }, 'dsh-workbench: same-origin web workbench routes')
}
