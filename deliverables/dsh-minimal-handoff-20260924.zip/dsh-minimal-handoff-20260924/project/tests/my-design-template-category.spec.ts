import { describe, expect, it } from 'vitest'
import { renderLocalWorkbenchPage } from '../src/local-app/page.js'

describe('my design template category', () => {
  const page = renderLocalWorkbenchPage()
  // Execute the actual filter emitted into the browser, not a duplicated predicate.
  const expression = page.match(/allTemplates\.filter\(item=>([\s\S]*?)\);status\.textContent/)?.[1]
  if (!expression) throw new Error('Template category predicate not found')
  const matches = new Function('item', 'filter', 'query', 'return (' + expression + ')') as
    (item: Record<string, unknown>, filter: string, query: string) => boolean
  const templates = [
    ...['prototype-design', 'prototype-design-header-filter', 'unified-b2b-dashboard-visual-design', 'datapulse-adaptive-dashboard']
      .map(id => ({ id, name: id, sourcePath: 'local:/templates/' + id + '/design.md' })),
    { id: 'public', name: 'Public Style', sourcePath: 'design-md/public/DESIGN.md' },
    { id: 'report', name: 'Report', provider: 'Lieflat Charts', kind: 'report' },
    { id: 'chart', name: 'Chart', provider: 'Lieflat Charts', kind: 'chart' },
  ]

  it('provides a separate category without removing existing options', () => {
    for (const value of ['all', 'my-designs', 'report', 'chart', 'style']) {
      expect(page).toContain('<option value=' + value + '>')
    }
    expect(page).toContain('我的设计规范')
  })

  it('includes every imported local design, even future imports and designs without previews', () => {
    expect(templates.filter(t => matches(t, 'my-designs', '')).map(t => t.id))
      .toEqual(templates.slice(0, 4).map(t => t.id))
    expect(matches({ name: 'New Design', sourcePath: 'local:/new/design.md', status: 'queued' }, 'my-designs', '')).toBe(true)
    expect(matches({ name: 'DataPulse', sourcePath: 'design-md/datapulse/DESIGN.md' }, 'my-designs', '')).toBe(false)
    expect(matches({ name: 'No source' }, 'my-designs', '')).toBe(false)
  })

  it('combines category and search without losing other category behavior', () => {
    expect(templates.filter(t => matches(t, 'my-designs', 'datapulse')).map(t => t.id)).toEqual(['datapulse-adaptive-dashboard'])
    expect(templates.filter(t => matches(t, 'my-designs', 'absent'))).toHaveLength(0)
    expect(templates.filter(t => matches(t, 'all', ''))).toHaveLength(7)
    expect(templates.filter(t => matches(t, 'style', '')).map(t => t.id)).toEqual(['public'])
    expect(templates.filter(t => matches(t, 'report', '')).map(t => t.id)).toEqual(['report'])
    expect(templates.filter(t => matches(t, 'chart', '')).map(t => t.id)).toEqual(['chart'])
  })
})
