# DSH 看板工作台：当前实现架构

核对日期：2026-09-15。代码基线：`48d34c5`。本文根据代码入口、路由、工具注册与部署实现整理；代码存在不代表生产部署验收完成。本文不修改运行服务。

## 1. 整体判断

当前产品是加载在 DSH 宿主中的看板插件。DSH 提供模型、Agent、原生会话及 Web 宿主；插件提供业务页面、看板工具、资产与版本管理、实时查询和发布分享。服务器看板运行于 Jupyter 容器，查看和刷新不需要经过作者本机。

不是所有源码目录都在当前主链路上：原生 Agent 对话是主要搭建入口；结构化 CSV 构建器、独立本地应用、远端资料库适配器以及独立 Codex 看板是并存的复用或兼容路径。

## 2. 信息架构：用户看见什么

| 一级入口 | 二级内容与操作 | 当前状态 |
|---|---|---|
| 新建看板 | 需求输入、单个 CSV 上传（20 MB）、通用数据智能体、对话执行、草稿卡片、预览、发布 | 已实现 |
| 新建看板／其他附件入口 | 从资料库添加、飞书文档附件 | 未开放 |
| 新建看板／专业智能体 | 经营分析、销售分析 | 未配置独立原生智能体，入口禁用 |
| 我的看板 | 目录与搜索、版本、预览或服务器查看、收藏、分享 | 已实现，具体操作受资产状态约束 |
| 看板详情 | 图表、指标、筛选、刷新、口径与 SQL 追溯 | 实时看板支持；SQL 是否展示取决于查看入口 |
| 分享窗口 | 链接、服务器发布状态、飞书接收人选择、卡片预览、发送 | 已实现；卡片不授予 Jupyter 权限 |
| 资料库／模板库 | 整页与图表模板、预览、选择和取消；设计风格参考 | 已实现 |
| 资料库／知识库 | 业务口径、文档、资料搜索与新建 | 占位；搜索、新建未开放 |
| 智能订阅 | 自动监控、后台订阅、通知 | 占位；不会后台执行或发消息 |
| 历史对话 | 恢复、重命名、置顶、归档与恢复、分享 | 已实现；归档不等于永久删除 |

信息架构关注导航与内容归属。它不应把数据库、MCP、Jupyter 等技术组件列成用户菜单。

## 3. 产品架构：能力如何组织

1. **交互层**：工作台导航、需求输入、对话过程、草稿卡片、看板目录、查看器、分享弹窗。
2. **任务与交付层**：原生会话绑定、任务上下文、工具执行、预检计划、断点状态、草稿保存与版本交付。
3. **看板业务能力层**：CSV 数据画像、模板应用、真实查询与筛选、图表来源追溯、预览、发布、分享与撤销。
4. **数据与资产层**：本地文件资料库、不可变版本、发布指针、会话关联、实时绑定、诊断与签名回执。远端元数据和对象存储是另一个可配置适配层。
5. **运行与集成层**：DSH 的 Agent/LLM/Web 能力、授权数据 MCP、OpenMetadata 语义服务、Jupyter 看板服务、飞书发送服务；Phoenix 为可选观测能力。

横向约束分布在具体服务中：上传大小与来源校验、查询字段和筛选白名单、版本绑定、数据授权指纹、发布签名、iframe 隔离。不能据此宣称已经具有企业级统一权限管理。

## 4. 主链路与代码入口

### 4.1 启动与页面挂载

`src/index.ts` 的 `apply/register` 创建资料库、追踪器、原生会话服务、Headless Agent 服务与 `LiveService`，注册看板工具、HTTP 路由，并启动本地分享监听。`src/client.ts` 将看板入口和内嵌视图接入 DSH 页面。

主要页面由 `src/local-app/page.ts` 生成，并组合历史、目录、交付与分享行为。当前不是一个完全独立的前端 SPA：宿主集成、生成的 HTML 和注入脚本共同组成页面。

`src/web-ui/host-routes.ts` 是 HTTP 接入中心，处理上传、会话输入、目录、资产、预览、发布、模板、实时查询和飞书相关请求。

### 4.2 静态 CSV 看板

用户输入与上传 → `AgentUploadStore` 保存输入 → 原生会话绑定上传及模板 → Agent 读取完整 CSV 并生成 HTML → `workbench_save_generated_dashboard` → 资料库保存私有草稿／不可变 revision → 用户预览 → 发布 → 静态分享。

`data-ingestion/source-integrity.ts` 等校验来源和计算约束；`dashboard-build`、`dashboard-export` 与 `dashboard-policy` 提供结构化构建、导出和策略能力。静态 CSV 发布后依旧是快照，不会因为部署而自动成为实时看板。

### 4.3 实时看板生成与查询

授权表发现 → 字段描述 → 组织 spec 与 HTML/provenance → 完整预检及真实试查询 → 保存 `planId` → 以 `planId + assetId` 保存草稿 → 预览 → 发布。

核心工具注册于 `src/tools.ts`：

- `workbench_live_capabilities`、`workbench_list_live_tables`、`workbench_describe_live_table`：能力和授权数据发现。
- `workbench_preflight_live_dashboard`、`workbench_trial_live_query`：结构、来源映射与真实数据验证。
- `workbench_create_live_dashboard`、`workbench_live_plan_status`：计划交付及恢复；同一计划重复保存复用既有结果。
- `workbench_live_diagnostic`：读取诊断。

`live-dashboard/service.ts` 负责 spec 校验、SQL 构建、执行、计划、绑定及分享授权；`filters.ts` 和 `filter-controls.ts` 处理受控筛选；`provenance.ts` 与 `inspector.ts` 负责图表到查询的映射与展示；`mcp.ts` 及其中的执行运行时连接查询执行。浏览器修改筛选后，由服务端校验并重新执行，不能提交任意 SQL。

保存状态包括 `ready/saving/saved`。`saving` 表示结果不确定时不能盲目重建，仍需核对原资产。当前计划写入按单实例串行化，不是分布式事务。

### 4.4 发布到服务器

发布按钮 → 本地固定 revision → `ServerDeployment` 准备包 → 浏览器经现有 Jupyter 登录会话传输 → 容器 `/publish` 验证授权与查询 → 写入版本与页面 → Ed25519 签名回执 → 本地验证并登记服务器链接 → UI 显示发布成功。

前端入口在 `local-app/server-publishing-ui.ts`；本地逻辑在 `live-dashboard/server-deployment.ts` 与 `server-publications.ts`；容器实现在 `deploy/live-server/publication-store.mjs`、`publish-page.mjs`、`server.mjs`。

注意：本地 release 快照先保存，远端成功后才显示完整发布成功。失败保留待完成状态，可使用同一版本重试，不需要重新生成看板。

### 4.5 服务器查看与飞书分享

查看者 → HTTPS 静态查看器 → 经已有登录的 Jupyter 内核桥 → 容器 `LiveService` → 授权数据源 → 数据回传 → iframe 更新图表。

`deploy/live-server/viewer-page.mjs` 和 `dsh_server_bridge.py` 承载查看与查询。`withCurrentLiveUI` 使本地与服务器应用同一套筛选和 SQL 说明升级；原始 revision HTML 保持不变。

飞书链路：工作台分享窗口 → 本地后端 → `deploy/online/server.mjs` → `feishu.mjs` → 应用机器人 → 卡片跳转服务器 URL。当前本地配置复用飞书 CLI。发布不自动发送卡片；发送成功也不等于接收人已拥有网络或查询访问权限。

## 5. 代码地图

| 路径（相对 dsh-workbench） | 职责 | 主链路地位 |
|---|---|---|
| `src/index.ts`、`src/client.ts` | 插件装配与 DSH 页面接入 | 主入口 |
| `src/web-ui/host-routes.ts` | 工作台 API 与页面路由 | 主入口 |
| `src/local-app/` | 页面、对话交付、历史、目录、分享 | 主 UI；另有独立开发入口 |
| `src/native-workbench-sessions.ts`、`src/native-task-context.ts` | 会话与上传／草稿关联、任务输入 | 主链路 |
| `src/headless-dashboard-agent.ts`、`src/workbench-failure-guard.ts` | 宿主 Agent 执行与失败处理 | 任务执行 |
| `src/tools.ts` | Agent 可调用业务工具 | 主工具层 |
| `src/live-dashboard/` | 查询、预检、绑定、筛选、来源、实时分享、部署登记 | 实时核心 |
| `src/data-ingestion/` | 上传、CSV 画像与来源完整性 | 数据输入 |
| `src/design-library/` | 模板目录、资源、风格与缓存 | 模板能力 |
| `src/library/` | 资产、版本、发布指针及适配器 | 资产核心 |
| `src/data-connectors/` | OMD 语义、只读连接器契约 | 集成与复用 |
| `src/agent-run/`、`src/ai/`、`src/dashboard-agent/` | 模型分析、结构化计划、运行事件 | 并存路径，不能替代原生主链路描述 |
| `src/dashboard-build/`、`src/dashboard-export/`、`src/dashboard-policy/` | 确定性构建、导出及约束 | 复用／离线能力 |
| `src/persistence/`、`migrations/` | PostgreSQL 仓储与迁移 | 可配置基础，不代表当前已接管所有状态 |
| `src/observability/` | Phoenix 可选模型调用追踪 | 开关控制，不是所有 Agent 调用自动全量覆盖 |
| `deploy/live-server/` | 通用 Jupyter 发布与实时查看服务 | 已部署路径 |
| `deploy/online/` | 静态分享及飞书传输 | 当前飞书配套服务 |
| `tests/` 与 `deploy/**/*.test.mjs` | 单元、流程和部署验证 | 代码证据，非全量生产验收 |
| `../codex-live-dashboard/` | 早期独立 Python 实时看板及部署工具 | 并存独立应用，不是 DSH 主入口 |

## 6. 存储与部署边界

| 位置 | 当前承载 | 边界 |
|---|---|---|
| 作者本机 DSH，3080 | 搭建、原生会话接入、草稿／资产、发布控制 | 作者操作仍依赖本机服务 |
| 本地分享，4340 | 固定版本实时分享兼容路径 | 不应与服务器独立运行混淆 |
| 本地配套服务，18087 | 静态分享与飞书 CLI 传输 | 当前发送链路依赖本机 |
| Jupyter 容器，4341 | 查询和部署服务；HTTPS 入口经 Jupyter | 已发布实时查看不经过本机；依赖公司网络与现有登录 |
| 本地文件资料库 | 草稿、revision、发布指针、历史与实时绑定 | `factory.ts` 默认 filesystem；服务器有独立持久目录 |
| 远端资料库适配器 | HTTP 元数据服务与对象存储 | 需显式配置；不能标为当前已完成生产切换 |

没有访客时不持续定时抓取；自动刷新是页面打开后的周期查询。进程退出可由下一次查询触发重启，容器重建仍需恢复入口，尚不是平台级守护。普通同事只读入口、统一登录、移动访问、完整生产恢复仍有待完成。

## 7. 后续维护的重点

- 产品导航中应持续区分已开放功能与占位能力。
- `page.ts` 与 `host-routes.ts` 汇集较多业务，后续可按对话、资产、发布、分享拆分，降低变更耦合。
- 保留原生主链路与兼容路径说明，避免误用旧生成器或旧分享路径。
- 企业权限、服务器恢复和模型工具协议问题应分别验收，不能由“某次看板能打开”推导全部完成。
