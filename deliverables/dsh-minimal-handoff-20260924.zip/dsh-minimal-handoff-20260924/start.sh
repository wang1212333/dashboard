#!/usr/bin/env sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
export DSH_HOME="$PWD/data/dsh"
export DSH_WORKBENCH_LIBRARY="$PWD/data/library"
exec dsh web
