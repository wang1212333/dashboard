# DSH 看板搭建：最小完整交接包

版本：2026-09-24 / 工作台0.4.0 / DSH0.1.1-rc.2。

## 这是什么
完整 DSH 看板插件的源码及预编译安装包，保留原生模型对话、CSV上传、看板生成、草稿、预览、版本、发布、实时数据适配器和分享集成。最小指去掉个人数据、依赖目录、日志、旧备份与重复编译目录，不是删减业务代码。

**需要联网安装 DSH/Node依赖并配置模型；不是免配置离线镜像，不是已验收的多用户生产一键部署包。** 默认文件资料库适合独立实例。面向团队上线仍需环境管理员配置身份、访问控制、HTTPS和进程守护。

## 最短启动步骤
1. 安装 Node.js24（本机验证24.18.0）和Chrome/Chromium。
2. `npm install -g @deepseek-ai/dsh@0.1.1-rc.2 pnpm@11.23.0`
3. 解压到固定目录。Windows运行 `./install.ps1`，Linux运行 `sh install.sh`。
4. 需要实时源时，复制 `.env.example` 为 `.env`，配置自己的授权地址和Token。Linux请填写 `DSH_BROWSER_EXECUTABLE` 为Chromium绝对路径。Windows默认使用已安装Chrome。
5. Windows运行 `./start.ps1`，Linux运行 `sh start.sh`，打开 DSH 打印的地址。
6. 首次在DSH配置自己的模型提供商、API Key和模型；模型未配置时无法AI生成。
7. 用 `project/fixtures/content-weekly.csv` 做上传→对话生成→草稿预览验收。自动发布到服务器属于可选集成，未配置服务端时可能显示“待完成服务器发布”，不可视为发布成功。

初次安装联网下载依赖；此包不携带node_modules。DSH预览版内部包获取受npm镜像/网络影响，若安装失败需让同事提供报错，不要更换为独立local:app来冒充完整DSH工作台。

## 文件
- `dsh-workbench-0.4.0.tgz`：直接安装的预编译插件，已移除作者电脑的libraryRoot绝对路径。
- `project/`：完整插件源码、测试、资源、锁文件、编译产物、迁移及集成服务代码。
- `project/deploy/online/`：可选静态链接/飞书服务，提供Docker Compose；此Compose不是完整DSH宿主。
- `project/deploy/live-server/`：现有Jupyter实时发布集成；安装脚本仍面向现有Jupyter环境，不能直接当通用Linux安装器。部署前阅读该目录README并按平台配置。
- `codex-live-dashboard/jupyter-deploy/index.html`：仅供实时服务构建器提取的传输代码片段，不是网页入口。
- `SHA256SUMS.txt`：除自身外所有交付文件的校验值。

## 数据与配置
安装/启动脚本将DSH宿主配置保存到 `data/dsh`、工作台资产保存到 `data/library`，与作者及同事已有DSH目录隔离。备份整个data目录及私有.env；源码更新不要覆盖数据。模型配置位于同事自己的隔离DSH配置中。

此包不含作者API Key、Token、飞书凭据、Cookie、业务CSV、已有看板/对话、个人模板缓存和数据库。OpenMetadata可选；实时数据、服务器发布、飞书各需单独配置。真实飞书发送需同事自己的机器人授权。

## 与最近原型的区别
最近调整的“我的作品”单HTML只是独立交互原型，并未合并到DSH生产页面。本包交付实际工作台代码，不把原型的按钮演示宣称为后端能力。原型文件位于原工程 deliverables/my-dashboards-prototype/index.html，不是本包的部署入口。

## 源码维护与验证
在project目录：`pnpm install --frozen-lockfile`，`pnpm build`，`pnpm exec vitest run tests --maxWorkers=2`。
源码构建需要DSH相关开发依赖，首次安装请确保能访问相应npm包。

交接前本机验证：完整构建成功；43个测试文件/185项测试通过；7项线上分享服务测试通过。同步了两处过时测试夹具，未绕过断言或关闭测试。降低并发解决浏览器测试的5秒竞争超时。
**尚未在同事机器或Linux/Docker上完成冷启动、真实模型调用、真实数据源及飞书端到端验收。** 没有Docker的本机无法完成镜像验证。安装后必须完成自己的模型/数据/访问验证。

## 模板许可
随源码保留的Lieflat模板使用PolyForm Noncommercial1.0.0，商业使用需作者许可；第三方图表/字体各自许可证保留。详见project/README.md与模板目录许可证。
