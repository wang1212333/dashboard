﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$env:DSH_HOME = Join-Path $PSScriptRoot 'data/dsh'
if (!(Get-Command dsh -ErrorAction SilentlyContinue)) { throw '请先安装：npm install -g @deepseek-ai/dsh@0.1.1-rc.2 pnpm@11.23.0' }
& dsh plugin --profile web add (Join-Path $PSScriptRoot 'dsh-workbench-0.4.0.tgz')
if ($LASTEXITCODE -ne 0) { throw '插件安装失败' }
Write-Host '安装完成。运行 ./start.ps1；首次需在 DSH 中配置模型。'
