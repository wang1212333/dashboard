﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$env:DSH_HOME = Join-Path $PSScriptRoot 'data/dsh'
$env:DSH_WORKBENCH_LIBRARY = Join-Path $PSScriptRoot 'data/library'
# DSH 启动器读取当前目录 .env；密钥不应写进脚本。
& dsh web
exit $LASTEXITCODE
