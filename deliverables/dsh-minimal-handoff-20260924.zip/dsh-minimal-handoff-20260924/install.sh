#!/usr/bin/env sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
export DSH_HOME="$PWD/data/dsh"
command -v dsh >/dev/null || { echo '先安装: npm install -g @deepseek-ai/dsh@0.1.1-rc.2 pnpm@11.23.0'; exit 1; }
dsh plugin --profile web add "$PWD/dsh-workbench-0.4.0.tgz"
echo '安装完成，执行 sh start.sh；首次需配置模型。'
